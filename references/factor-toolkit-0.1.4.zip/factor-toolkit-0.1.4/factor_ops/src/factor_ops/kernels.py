"""逐日序列/截面矩阵核（map_elements 或逐日循环用）。🦀 Rust 候选。

无法写成 Polars 表达式的整段序列逻辑放这里：因子文件里
``group_by(code,date).agg(_l=pl.col(...))`` 拿到 list 列后
``map_elements(O.<kernel>, return_dtype=pl.Float64)``。
数学必须在 ops——因子文件只做组合（AGENTS.md 算子白名单）。
"""

import numpy as np


def iforest_scores(x, *, n_estimators: int, seed: int) -> np.ndarray:
    """Isolation Forest 截面异常度（Liu-Ting-Zhou 2008,文献标准直进）。

    x: (n_samples, n_features) 截面特征矩阵(如每票近 60 日的收益+相对量轨迹);
    返回 异常度 = −score_samples ∈ 大约 [0.35, 0.85],**越大越异常**。

    性质:纯截面无监督(只用当日截面、无标签、无前视,与 cs_rank 同 PIT 性质);
    固定 seed 下确定性;分数与 contamination 无关(那只是硬分类阈值,连续
    用法不需要)。噪声参数 keyword-only 无默认(n_estimators 决定方差,seed 定复现)。
    """
    from sklearn.ensemble import IsolationForest

    x = np.asarray(x, dtype=np.float64)
    if x.ndim != 2 or x.shape[0] < 10:
        raise ValueError(f"iforest_scores: 需要 (n≥10, k) 矩阵,实际 {x.shape}")
    m = IsolationForest(n_estimators=n_estimators, random_state=seed, n_jobs=1)
    m.fit(x)
    return -m.score_samples(x)


def hurst_rs(values) -> float | None:
    """R/S Hurst 指数（Hurst 1951 / Mandelbrot-Wallis 1969），∈ [0,1]。

    对 log 收益在**对数间隔**窗口 w（4 起，×1.5 递增至 n//2）上做非重叠分块 R/S：
    R = range(cumsum(去均值块))，S = 块内 std(ddof=0)，
    log(mean R/S) 对 log(w) 的 OLS 斜率即 Ĥ，clip 到 [0,1]。

    H≈0.5 随机游走；>0.5 持续性（趋势）；<0.5 反持续（均值回复）。
    输入：一日内价格序列（原价，内部取 log 收益）；有效点 <10 或
    可用窗口 <3 → None。语义平移自 ex_dividend factor_market_behavior，
    窗口网格从密集线性改为对数间隔——log-log 回归的文献标准采样
    （Mandelbrot-Wallis），且快 ~11x（240bar：117 窗→10 窗）。
    """
    px = np.asarray(values, dtype=np.float64)
    px = px[np.isfinite(px)]
    if len(px) < 10:
        return None
    lr = np.diff(np.log(px + 1e-10))
    n = len(lr)
    if n // 2 < 4:
        return None
    windows, w = [], 4
    while w <= n // 2:
        windows.append(w)
        w = max(w + 1, int(round(w * 1.5)))
    rs_logs, size_logs = [], []
    for w in windows:
        k = n // w
        chunks = lr[: k * w].reshape(k, w)
        dev = np.cumsum(chunks - chunks.mean(axis=1, keepdims=True), axis=1)
        r = dev.max(axis=1) - dev.min(axis=1)
        s = chunks.std(axis=1)
        ok = s > 1e-10
        if ok.any():
            rs_logs.append(np.log((r[ok] / s[ok]).mean()))
            size_logs.append(np.log(w))
    if len(rs_logs) < 3:
        return None
    x = np.asarray(size_logs)
    y = np.asarray(rs_logs)
    x_dm = x - x.mean()
    denom = float((x_dm**2).sum())
    if denom < 1e-12:
        return None
    h = float((x_dm * (y - y.mean())).sum() / denom)
    return float(min(max(h, 0.0), 1.0))
