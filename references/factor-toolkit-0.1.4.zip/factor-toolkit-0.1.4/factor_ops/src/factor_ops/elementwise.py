"""元素级算子：带语义保护的标量数学。

分界线：纯加减乘除/平方/绝对值**不包装**——polars 表达式原生支持
（x + y, x / y, x ** 2, x.abs(), -x, x.sign()），包装只会多一层名字。
本族只收"裸算术有陷阱"的工具：

  safe_div     除零 -> null（不是 inf；inf 会静默穿过整条管道毒化下游）
  s_log        x <= 0 -> null（宁缺毋 NaN）
  s_sqrt       x <  0 -> null
  signed_power sign(x)·|x|^a（Alpha101 signedpower：压幅保号，a<1 抑制极端）
"""

import polars as pl


def _e(x: str | pl.Expr) -> pl.Expr:
    return pl.col(x) if isinstance(x, str) else x


def safe_div(a: str | pl.Expr, b: str | pl.Expr) -> pl.Expr:
    a, b = _e(a), _e(b)
    return pl.when(b != 0).then(a / b).otherwise(None)


def s_log(x: str | pl.Expr) -> pl.Expr:
    x = _e(x)
    return pl.when(x > 0).then(x.log()).otherwise(None)


def s_sqrt(x: str | pl.Expr) -> pl.Expr:
    x = _e(x)
    return pl.when(x >= 0).then(x.sqrt()).otherwise(None)


def signed_power(x: str | pl.Expr, a: float) -> pl.Expr:
    x = _e(x)
    return x.sign() * x.abs() ** a


def log_contrast(a: str | pl.Expr, b: str | pl.Expr) -> pl.Expr:
    """log(1+a) − log(1+b)：双边机制的标准对比构造（skill §1.5）。

    a = 租金一致桶强度，b = 对立桶强度（均应 ≥ 0）；任一侧 1+x ≤ 0
    时输出 null 而非 NaN。量纲稳定、不爆比、天然带号。
    """
    a, b = _e(a), _e(b)
    return pl.when((1 + a > 0) & (1 + b > 0)).then(
        (1 + a).log() - (1 + b).log()
    ).otherwise(None)


def round_level(price: str | pl.Expr, step: float) -> pl.Expr:
    """最近的整数关口价：round(p/step)·step（关口距离 = (p−level)/level
    由调用方用 safe_div 组合；step 是研究口径，进 CARD params）。"""
    p = _e(price)
    return (p / step).round(0) * step
