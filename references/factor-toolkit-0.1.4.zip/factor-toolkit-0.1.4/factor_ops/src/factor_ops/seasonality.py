"""same-minute trailing baseline（日内季节性基线）。

列命名空间：``_ssn_*``。输入须先经 prepare_minute_frame
（(code, dt) 已排序——over("code", 分钟) 分组内即按日期升序，
rolling 的时序假设由此成立）。
"""

import polars as pl

from factor_ops._contracts import ContractError, require_columns


def add_same_minute_baseline(
    lf: pl.LazyFrame,
    *,
    value_col: str | list[str],
    baseline_window_days: int,
    min_samples: int,
    stat: str = "mean",
) -> pl.LazyFrame:
    """``_ssn_base_<col>`` = 同一 (code, 分钟) 在**过去** N 个交易日上
    value_col 的滚动 mean / median。

    两条尺子纪律：
    - 无自含：先 shift(1) 再 rolling——当日值绝不进自己的基线；
    - stat 是估计量选择（研究口径，进 CARD params 并显式传）：
      ``"mean"`` 高效但会被历史离群日污染——60 日窗里一次闪崩会把
      之后两个多月的尺子拖歪；``"median"`` 50% 崩溃点，肥尾比值类
      （弹性、份额比）必须用它。
    样本不足 min_samples 的日子输出 null（宁缺毋滥，下游显式处理）。
    value_col 可传列表：多列共享同一窗口分区单遍计算（双腿类构造的
    性能关键——分区只做一次）。
    """
    cols = [value_col] if isinstance(value_col, str) else list(value_col)
    require_columns(
        lf.collect_schema().names(), ["code", "dt", *cols],
        "add_same_minute_baseline",
    )
    if stat not in ("mean", "median"):
        raise ContractError(
            f"add_same_minute_baseline: stat 只支持 mean/median，实际 {stat!r}"
        )

    def _roll(c: str) -> pl.Expr:
        shifted = pl.col(c).shift(1)
        roll = (
            shifted.rolling_mean(baseline_window_days, min_samples=min_samples)
            if stat == "mean"
            else shifted.rolling_median(baseline_window_days, min_samples=min_samples)
        )
        return roll.over("code", "_ssn_minute").alias(f"_ssn_base_{c.lstrip('_')}")

    return lf.with_columns(_ssn_minute=pl.col("dt").dt.time()).with_columns(
        [_roll(c) for c in cols]
    )
