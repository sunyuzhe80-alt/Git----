"""截面算子 cs_*：同一交易日全市场横截面上的变换。

输入 pl.Expr 或列名，输出 pl.Expr（可任意嵌套组合）；分组 .over("date")
已内建，作用框架须含 date 列。null 不参与统计、原位保留。
"""

import polars as pl


def _e(x: str | pl.Expr) -> pl.Expr:
    return pl.col(x) if isinstance(x, str) else x


def cs_rank(x: str | pl.Expr) -> pl.Expr:
    """截面百分位秩 ∈ (0, 1]（Alpha101 的 rank；tie 取平均秩）。"""
    x = _e(x)
    return (x.rank("average") / x.count()).over("date")


def cs_zscore(x: str | pl.Expr) -> pl.Expr:
    x = _e(x)
    return ((x - x.mean()) / x.std()).over("date")


def cs_demean(x: str | pl.Expr) -> pl.Expr:
    x = _e(x)
    return (x - x.mean()).over("date")


def cs_scale(x: str | pl.Expr, a: float = 1.0) -> pl.Expr:
    """L1 归一：Σ|x| = a（Alpha101 的 scale）。"""
    x = _e(x)
    return (x / x.abs().sum() * a).over("date")


def cs_daily_spearman(df: pl.DataFrame, x: str, y: str) -> float:
    """日度截面 spearman 均值（克隆/增量对账的标准件，提炼门入腰：
    已在 kill_if 对账中手搓 ≥5 次）。

    固化两个踩过的坑：NaN 日（截面零方差时 corr 为 NaN，drop_nulls
    不过滤）与 null 日一并剔除；无有效日返回 nan。
    """
    cs = df.group_by("date").agg(
        _c=pl.corr(pl.col(x).rank(), pl.col(y).rank())
    )["_c"].drop_nulls()
    cs = cs.filter(cs.is_finite())
    return float(cs.mean()) if cs.len() else float("nan")


def cs_winsor(x: str | pl.Expr, q: float = 0.01) -> pl.Expr:
    """截面分位截尾：压到 [q, 1-q] 分位内（去极值是截面尺子的一部分，
    q 属于研究口径，写因子时进 CARD params）。"""
    x = _e(x)
    return x.clip(x.quantile(q), x.quantile(1 - q)).over("date")
