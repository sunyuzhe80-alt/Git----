"""realized 族算子：日内已实现矩 / 跳跃分解（高频计量标准定义）。

理论锚点（即"泰勒展开描述跳跃"的严格形式）：价格半鞅的二次变差
QV = ∫σ²dt（连续部分）+ Σ J²（跳跃部分）。日内收益 {r_i, i=1..n} 满足：

  RV  = Σ r_i²                       → QV（全部）
  BPV = (π/2) Σ |r_i||r_{i-1}|       → ∫σ²dt（对跳跃稳健，BNS 2004）
  JV  = max(RV - BPV, 0)             → 跳跃方差
  RS⁻ = Σ r_i² · 1{r_i<0}，RS⁺ 同理  → 半方差（Patton-Sheppard 2015）
  SJ  = RS⁺ - RS⁻                    → 有符号跳跃代理
  RSkew = √n · Σ r_i³ / RV^{3/2}     → 已实现偏度（Amaya et al. 2015）
  RKurt =  n · Σ r_i⁴ / RV²          → 已实现峰度

实现说明：
- 全部可用 Polars groupby 聚合表达（无需 Rust——下沉触发条件见 AGENTS.md）。
- 输入是 bar 级 LazyFrame + 收益列名；**样本选择归调用方**（约束 3）：
  丢不丢 09:30 竞价收益、剔不剔零成交 bar，在因子文件 filter，这里只对
  非 null 收益计算。null 剔除后序列按原顺序拼接（BPV 的相邻对跨过空洞）。
- 输出是 (code, date) 日表（独立 schema，不再加 _前缀）。
- min_obs 无默认值：有效收益数不足时整行指标置 null（宁缺毋滥）。
"""

import math

import polars as pl

from factor_ops._contracts import require_columns


def daily_realized_measures(
    lf: pl.LazyFrame,
    *,
    ret_col: str,
    min_obs: int,
) -> pl.LazyFrame:
    """逐 (code, date) 输出：n_ret / rv / bpv / jv / rs_neg / rs_pos /
    signed_jump / rskew / rkurt。"""
    require_columns(
        lf.collect_schema().names(), ["code", "date", ret_col],
        "daily_realized_measures",
    )
    r = pl.col(ret_col).drop_nulls()
    n = r.len()
    rv = (r**2).sum()
    bpv = (math.pi / 2) * (r.abs() * r.abs().shift(1)).sum()
    rs_neg = (r.filter(r < 0) ** 2).sum()
    rs_pos = (r.filter(r > 0) ** 2).sum()
    rskew = (n.cast(pl.Float64).sqrt() * (r**3).sum()) / rv**1.5
    rkurt = (n * (r**4).sum()) / rv**2

    day = lf.group_by("code", "date").agg(
        n.alias("n_ret"),
        rv.alias("rv"),
        bpv.alias("bpv"),
        rs_neg.alias("rs_neg"),
        rs_pos.alias("rs_pos"),
        rskew.alias("rskew"),
        rkurt.alias("rkurt"),
    )
    measures = ["rv", "bpv", "rs_neg", "rs_pos", "rskew", "rkurt"]
    return (
        day.with_columns(
            # 样本不足：全部指标置 null，但保留行（缺数据是事实，不是没这天）
            [
                pl.when(pl.col("n_ret") >= min_obs).then(pl.col(c)).alias(c)
                for c in measures
            ]
        )
        .with_columns(
            (pl.col("rv") - pl.col("bpv")).clip(lower_bound=0).alias("jv"),
            (pl.col("rs_pos") - pl.col("rs_neg")).alias("signed_jump"),
        )
        .sort("code", "date")
    )
