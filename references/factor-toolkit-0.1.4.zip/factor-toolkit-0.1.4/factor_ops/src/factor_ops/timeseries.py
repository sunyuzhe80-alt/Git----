"""时序算子 ts_*：每只票自身日度序列上的变换。

输入 pl.Expr 或列名，输出 pl.Expr；分组 .over("code") 已内建。
作用框架须为 (code, date) 粒度且**已按 (code, date) 排序**——乱序输入
产出错值而非异常，排序契约由调用方负责（prepare 出的日表天然满足）。

滚动窗口的默认口径是最严格的：不足 window 即 null。要放宽必须显式传
min_samples——默认值选最保守口径，不构成隐藏自由度。
"""

import numpy as np
import polars as pl


def _e(x: str | pl.Expr) -> pl.Expr:
    return pl.col(x) if isinstance(x, str) else x


def ts_delay(x: str | pl.Expr, d: int) -> pl.Expr:
    """d 日前的值（Alpha101 的 delay）。"""
    return _e(x).shift(d).over("code")


def ts_delta(x: str | pl.Expr, d: int) -> pl.Expr:
    """当前值 - d 日前的值（Alpha101 的 delta）。"""
    x = _e(x)
    return (x - x.shift(d)).over("code")


def ts_mean(x: str | pl.Expr, w: int, min_samples: int | None = None) -> pl.Expr:
    return _e(x).rolling_mean(w, min_samples=min_samples).over("code")


def ts_std(x: str | pl.Expr, w: int, min_samples: int | None = None) -> pl.Expr:
    return _e(x).rolling_std(w, min_samples=min_samples).over("code")


def ts_sum(x: str | pl.Expr, w: int, min_samples: int | None = None) -> pl.Expr:
    return _e(x).rolling_sum(w, min_samples=min_samples).over("code")


def ts_min(x: str | pl.Expr, w: int, min_samples: int | None = None) -> pl.Expr:
    return _e(x).rolling_min(w, min_samples=min_samples).over("code")


def ts_max(x: str | pl.Expr, w: int, min_samples: int | None = None) -> pl.Expr:
    return _e(x).rolling_max(w, min_samples=min_samples).over("code")


def ts_quantile(x: str | pl.Expr, w: int, q: float, min_samples: int | None = None) -> pl.Expr:
    """过去 w 日窗口内的第 q 分位（order statistic by position）。

    ts_rank 的对偶（值↔秩）；ts_min=q0 / ts_max=q1 的一般化。是"排序表示"的原子
    单元（Cakici 2024 统一线性框架的排序序列任意切片）。分位口径，厚尾稳健（§0b）。
    """
    return _e(x).rolling_quantile(q, interpolation="linear", window_size=w, min_samples=min_samples).over("code")


def ts_qskew(x: str | pl.Expr, w: int, min_samples: int | None = None) -> pl.Expr:
    """过去 w 日窗口内的 Bowley 分位偏度 (Q3+Q1-2*Q2)/(Q3-Q1) ∈ [-1,1]。

    排序曲线的不对称度——右偏(>0)= 右尾肥（如彩票/最高单日收益拥挤）。
    moment 偏度厚尾下不稳，故用分位版（§0b）；分母近零(Q3≈Q1)置 null。
    """
    q1 = ts_quantile(x, w, 0.25, min_samples)
    q2 = ts_quantile(x, w, 0.50, min_samples)
    q3 = ts_quantile(x, w, 0.75, min_samples)
    iqr = q3 - q1
    return pl.when(iqr > 1e-12).then((q3 + q1 - 2 * q2) / iqr).otherwise(None)


def ts_corr(x: str | pl.Expr, y: str | pl.Expr, w: int) -> pl.Expr:
    """滚动 pearson 相关（Alpha101 的 correlation）。"""
    return pl.rolling_corr(_e(x), _e(y), window_size=w).over("code")


def ts_decay_linear(
    x: str | pl.Expr, w: int, min_samples: int | None = None
) -> pl.Expr:
    """线性衰减加权均值，最近一天权重最大（Alpha101 的 decay_linear）。

    shift 式实现而非 rolling(weights=...)：polars 的带权 rolling 遇到
    null 数组会 panic（已踩坑）。语义：窗口内非 null 值按权重重归一的
    加权均值；非 null 数 < min_samples 则 null（默认 = w，严格满窗，
    与全库口径一致；放宽须显式传）。
    """
    x = _e(x)
    ms = w if min_samples is None else min_samples
    num = sum(
        (float(w - i) * x.shift(i).fill_null(0.0) for i in range(w)),
        start=pl.lit(0.0),
    )
    den = sum(
        (float(w - i) * x.shift(i).is_not_null().cast(pl.Float64) for i in range(w)),
        start=pl.lit(0.0),
    )
    cnt = sum(
        (x.shift(i).is_not_null().cast(pl.Int32) for i in range(w)),
        start=pl.lit(0),
    )
    return pl.when(cnt >= ms).then(num / den).otherwise(None).over("code")


def ts_hawkes(x: str | pl.Expr, decay: float) -> pl.Expr:
    """Hawkes 自激强度(指数核,固定衰减 β):每个激励 x_i 对当前强度的贡献按 decay^(t-i)
    几何衰减、自激累积(无限记忆 / 聚集)。decay = exp(−β) ∈ [0,1):0 = 无记忆(恒等 x),
    →1 = 长记忆。填补 ts_decay_linear(线性核)之外的**指数核**;decay 预注册,非 MLE 估计。

    用 ewm(adjust=False)稳定 IIR 递归:λ_t = (1−decay)·x_t + decay·λ_{t-1},脉冲响应即指数核
    [1, decay, decay², …](归一常数 1−decay 截面不变,排序用不受影响)。须 (code,date) 已排序。
    reference:脉冲 x=[1,0,0,…] → [1, decay, decay², …];decay=0 → x 恒等。
    """
    return _e(x).ewm_mean(alpha=1.0 - decay, adjust=False).over("code")


def ts_decay_var(
    frame: pl.DataFrame | pl.LazyFrame,
    value_col: str,
    decay_col: str,
    *,
    group: str = "code",
    date_col: str = "date",
    out_col: str = "_rp",
) -> pl.DataFrame:
    """时变衰减的运行均值(Grinblatt-Han 2005 参考价 RP):
        RP_t = d_t · x_t + (1 − d_t) · RP_{t-1},  RP_首 = x_首

    是 ts_decay_linear(固定权重)的**时变推广**:权重由 decay_col(如换手率 d_t∈[0,1])逐日决定;
    凸组合 → 数值稳(RP 恒在历史价区间内)。x null(停牌)按 carry 处理(沿用上一 RP)。

    **frame 级 op(非 expr)**:polars 无原生 scan,用宽矩阵(日期×group)向量化跨 group、循环 date。
    要求 frame 每 (group,date) 唯一;d 须已 clip 到 [0,1]。返回 frame + out_col。
    reference:d≡1 → RP=x;d≡0 → RP=x_首(恒定)。
    """
    df = frame.collect() if isinstance(frame, pl.LazyFrame) else frame
    pv_x = df.pivot(index=date_col, on=group, values=value_col).sort(date_col)
    pv_d = df.pivot(index=date_col, on=group, values=decay_col).sort(date_col)
    cols = [c for c in pv_x.columns if c != date_col]
    X = pv_x.select(cols).fill_null(strategy="forward").to_numpy()
    D = np.nan_to_num(pv_d.select(cols).to_numpy(), nan=0.0)
    RP = np.full_like(X, np.nan, dtype=float)
    prev = np.full(X.shape[1], np.nan)
    for t in range(X.shape[0]):
        xt, dt = X[t], D[t]
        prev = np.where(np.isnan(prev), xt, dt * xt + (1.0 - dt) * prev)
        RP[t] = prev
    rp_long = pl.DataFrame(
        {date_col: pv_x[date_col], **{c: RP[:, i] for i, c in enumerate(cols)}}
    ).unpivot(index=date_col, variable_name=group, value_name=out_col)
    return df.join(rp_long, on=[date_col, group], how="left")


def ts_baseline(x: str | pl.Expr, w: int, min_samples: int | None = None) -> pl.Expr:
    """截至**昨日**的 w 日滚动均值——尺子语义（同 same_minute_baseline
    的纪律：当期值不进自己的基线）。

    与 ts_mean 的分工：ts_mean 是特征（含当期，信息汇总）；ts_baseline
    是基准（先 shift 再 rolling，供"今日值 / 历史正常水平"类比较用）。
    """
    return _e(x).shift(1).rolling_mean(w, min_samples=min_samples).over("code")


def _ffd_weights(d: float, window: int) -> list[float]:
    """固定窗口分数阶差分权重：w_0=1, w_k = -w_{k-1}·(d-k+1)/k。"""
    w = [1.0]
    for k in range(1, window):
        w.append(-w[-1] * (d - k + 1) / k)
    return w


def ts_fracdiff(x: str | pl.Expr, d: float, window: int) -> pl.Expr:
    """分数阶差分（FFD 固定窗口版，López de Prado AFML ch.5）：
    y_t = Σ_k w_k · x_{t-k}。

    d 是"记忆 ↔ 平稳"的连续旋钮：d=0 恒等（全记忆、不平稳），
    d=1 一阶差分（无记忆、平稳），d∈(0,1) 两者折中——比一阶差分
    保留更多低频记忆的同时获得平稳性。退化检验：d=1, window=2
    即 ts_delta(x, 1)。窗口未满严格 null。

    已知限制：polars 带权 rolling 在含 null 序列上 panic——输入须无
    null（FFD 权重有符号结构，不能像 decay_linear 那样跳空重归一）。
    """
    weights = list(reversed(_ffd_weights(d, window)))  # polars 权重序：旧→新
    return _e(x).rolling_sum(window, weights=weights).over("code")


def ts_rank(x: str | pl.Expr, w: int) -> pl.Expr:
    """当前值在过去 w 日窗口内的百分位秩（Alpha101 的 ts_rank）。

    Polars 无原生滚动秩——这是 Rust plugin 的**首个动工候选**
    （AGENTS.md 触发条件 ①）。在它落地前先用就地表达：O(w) 次 shift
    比较，w ≤ 60 时可接受，更大窗口等 kernel。
    """
    x = _e(x)
    hits = [(x > x.shift(i)).cast(pl.Int32) for i in range(1, w)]
    cnt = [(x.shift(i).is_not_null()).cast(pl.Int32) for i in range(1, w)]
    n_le = pl.sum_horizontal(hits)
    n_valid = pl.sum_horizontal(cnt)
    return (
        pl.when(n_valid == w - 1)        # 严格口径：窗口必须满
        .then((n_le + 1) / (n_valid + 1))
        .otherwise(None)
        .over("code")
    )


def _rolling_arg(s: pl.Series, w: int, want_max: bool) -> pl.Series:
    """单条(已按 date 升序)序列的滚动 arg 位置——numpy 向量化滑窗。

    返回 1..w(np.arg*(window)+1,首个极值=最旧),窗口未满 null。比 O(w) shift 表达式快几个数量级。
    """
    a = s.to_numpy().astype("float64")
    n = a.shape[0]
    out = np.full(n, np.nan)
    if n >= w:
        sw = np.lib.stride_tricks.sliding_window_view(a, w)              # (n-w+1, w)
        idx = np.argmax(sw, axis=1) if want_max else np.argmin(sw, axis=1)  # 首个极值(最旧), 0..w-1
        out[w - 1:] = idx + 1
    return pl.Series(out).fill_nan(None)   # 不满窗 NaN -> null(否则污染 evaluate)


def ts_argmax(x: str | pl.Expr, w: int) -> pl.Expr:
    """过去 w 日窗口内最大值的位置（Alpha101 Ts_ArgMax / GTJA HIGHDAY）。

    返回 1..w：1=最旧、w=当天（最近），并列取最旧（=np.argmax(window)+1）。
    numpy 向量化滑窗(map_batches 按 code 分组)实现——比 O(w) shift 表达式快得多。
    须 (code,date) 已排序;窗口未满严格 null。
    """
    return _e(x).map_batches(lambda s: _rolling_arg(s, w, True), return_dtype=pl.Float64).over("code")


def ts_argmin(x: str | pl.Expr, w: int) -> pl.Expr:
    """过去 w 日窗口内最小值的位置（Alpha101 Ts_ArgMin / GTJA LOWDAY）。1..w,并列取最旧(=np.argmin+1)。"""
    return _e(x).map_batches(lambda s: _rolling_arg(s, w, False), return_dtype=pl.Float64).over("code")
