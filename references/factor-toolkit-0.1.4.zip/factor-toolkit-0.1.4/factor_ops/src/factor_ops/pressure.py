"""pressure 族算子：分钟收益等强度类数学工具。

列命名空间：本模块只产 ``_prs_*`` 列（约束：列契约显式化）。
输入须先经 prepare_minute_frame（已按 (code, dt) 排序、带 date 列）。
本模块只放语义无歧义的数学工具；卡片专属的组合逻辑（pressure_total
之类）留在因子文件，活过 ≥2 张卡再提进来（rule of three）。
"""

import polars as pl

from factor_ops._contracts import require_columns


def add_ret_1m(lf: pl.LazyFrame) -> pl.LazyFrame:
    """分钟收益 ``_prs_ret_1m`` = close / 前一根 close - 1。

    按 (code, date) 分组：每日首根（09:30 竞价 bar）为 null，
    绝不跨日、跨码串价。
    """
    require_columns(lf.collect_schema().names(), ["code", "date", "close"], "add_ret_1m")
    return lf.with_columns(
        (pl.col("close") / pl.col("close").shift(1).over("code", "date") - 1).alias(
            "_prs_ret_1m"
        )
    )
