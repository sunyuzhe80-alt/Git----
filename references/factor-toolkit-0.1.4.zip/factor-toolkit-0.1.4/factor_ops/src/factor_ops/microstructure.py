"""微观结构算子（bar 级标注）。列命名空间：``_mst_*``。

只放可复用原语，不放场景逻辑——Kyle λ、OFI、Amihud、拆单检测等
全部由本族 + daily.d_* 原语组合而成（见 docs/math-toolbox.md §2b）。
"""

import polars as pl

from factor_ops._contracts import require_columns


def add_tick_rule_sv(lf: pl.LazyFrame) -> pl.LazyFrame:
    """网关算子：tick-rule 带号成交量 ``_mst_sv``。

    sv = sign(Δclose) · volume，价格不动时沿用上一非零符号（标准
    tick rule）；每日首根无前价，符号取 0（竞价 bar 不猜方向）。

    测量误差性质：1min 粒度方向误判约 2-3 成，使下游 λ/OFI 类估计
    **向零衰减但保序**——截面 rank 后可用，绝对值不可跨期比。
    hf_trades.aggressor_side 灌数据后可无缝替换本代理，下游定义不变。
    """
    require_columns(
        lf.collect_schema().names(), ["code", "date", "close", "volume"],
        "add_tick_rule_sv",
    )
    sign = pl.col("close").diff().sign()
    sign = (
        pl.when(sign == 0).then(None).otherwise(sign).forward_fill().fill_null(0)
    )
    return lf.with_columns((sign * pl.col("volume")).over("code", "date").alias("_mst_sv"))


def add_bvc_buy_ratio(
    lf: pl.LazyFrame,
    *,
    sigma_window: int,
    min_samples: int,
    clip: float,
) -> pl.LazyFrame:
    """BVC（Bulk Volume Classification，Easley–López de Prado–O'Hara）买量分类。

    每 bar 成交量按标准化价格变动过正态 CDF 劈成买/卖——比 ``add_tick_rule_sv``
    的硬符号平滑（bulk 分类而非 ±1）：

        z         = Δlog(close) / rolling_std(Δlog(close), sigma_window)   （σ 跨天滚动）
        buy_ratio = Φ(z) ≈ 1/(1+exp(−1.702·z))   （logistic 近似正态CDF，误差<1e-2，保 lazy）
        σ 无效（首窗/停牌）时退回 CLV：(1+clv)/2，clv=((c−l)−(h−c))/(h−l)
        buy_ratio ∈ [clip, 1−clip]

    产出（``_mst_*`` 命名空间）：
      ``_mst_buy_ratio``  买量占比 ∈ [clip, 1−clip]
      ``_mst_bvc_sv``     BVC 带号成交量 = volume·(2·buy_ratio−1)（``_mst_sv`` 的平滑版）
    买量 = volume·_mst_buy_ratio；净买 = _mst_bvc_sv；日内净买占比 = Σ_mst_bvc_sv / Σvolume。

    噪声参数 keyword-only 无默认（sigma_window 决定 σ 是快/慢估计量，必须显式传）。
    测量误差：1min 粒度 + 价格推方向，**非真 order flow**（方向误判向零衰减、保序，
    截面 rank 后可用，绝对值不可跨期比）。hf_trades.aggressor_side 灌数后可无缝替换，
    下游定义不变。参考：Easley, López de Prado & O'Hara (2012) VPIN。
    """
    require_columns(
        lf.collect_schema().names(),
        ["code", "date", "high", "low", "close", "volume"],
        "add_bvc_buy_ratio",
    )
    lr = (pl.col("close") / pl.col("close").shift(1).over("code", "date")).log()
    lr = pl.when(lr.is_infinite() | lr.is_nan()).then(0.0).otherwise(lr)
    lf = lf.with_columns(
        lr.alias("_mst_lr")
    ).with_columns(
        pl.col("_mst_lr")
        .rolling_std(window_size=sigma_window, min_samples=min_samples)
        .over("code")
        .alias("_mst_sig")
    )
    z = pl.col("_mst_lr") / pl.col("_mst_sig")
    z = pl.when(z.is_infinite() | z.is_nan()).then(0.0).otherwise(z)
    cdf = 1.0 / (1.0 + (-1.702 * z).exp())  # logistic ≈ 标准正态 CDF
    clv = ((pl.col("close") - pl.col("low")) - (pl.col("high") - pl.col("close"))) / (
        pl.col("high") - pl.col("low")
    )
    clv = pl.when(clv.is_infinite() | clv.is_nan()).then(0.0).otherwise(clv)
    clv_ratio = (1.0 + clv) / 2.0
    buy_ratio = (
        pl.when(pl.col("_mst_sig").is_not_null() & (pl.col("_mst_sig") > 1e-12))
        .then(cdf)
        .otherwise(clv_ratio)
        .clip(clip, 1.0 - clip)
    )
    return (
        lf.with_columns(buy_ratio.alias("_mst_buy_ratio"))
        .with_columns((pl.col("volume") * (2.0 * pl.col("_mst_buy_ratio") - 1.0)).alias("_mst_bvc_sv"))
        .drop("_mst_lr", "_mst_sig")
    )
