"""path 族算子：日内路径定位的数学工具。

列命名空间：``_path_*``。输入须先经 prepare_minute_frame。
约定：tie（一日多根同为最低/最高）取**最早**那根（arg_min/arg_max 语义），
这是未来 kernel 必须复刻的边界语义之一。
"""

import polars as pl

from factor_ops._contracts import require_columns


def add_day_path_marks(lf: pl.LazyFrame) -> pl.LazyFrame:
    """逐 bar 标注当日路径位置：

    - ``_path_bar_idx``  当日第几根 bar（0 起；09:30 竞价 bar 是 0）
    - ``_path_n_bars``   当日 bar 总数
    - ``_path_low_idx``  当日最低 low 所在 bar 序号（tie 取最早）
    - ``_path_high_idx`` 当日最高 high 所在 bar 序号（tie 取最早）
    - ``_path_since_low``当前 bar 相对 low bar 的位移（负=低点前）

    因子文件由此表达 "低点后 N 分钟"、"尾段修复" 等窗口，
    排除/截窗动作仍由因子文件显式 filter。
    """
    require_columns(
        lf.collect_schema().names(), ["code", "date", "low", "high"],
        "add_day_path_marks",
    )
    g = ("code", "date")
    return lf.with_columns(
        pl.int_range(pl.len()).over(*g).alias("_path_bar_idx"),
        pl.len().over(*g).alias("_path_n_bars"),
        pl.col("low").arg_min().over(*g).alias("_path_low_idx"),
        pl.col("high").arg_max().over(*g).alias("_path_high_idx"),
    ).with_columns(
        (pl.col("_path_bar_idx") - pl.col("_path_low_idx")).alias("_path_since_low")
    )
