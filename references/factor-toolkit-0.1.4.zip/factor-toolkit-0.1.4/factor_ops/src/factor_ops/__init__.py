"""算子库——因子 = 算子的组合（Alpha101 式组织）。

分类（一个文件 = 一个算子族）：

  cross_section   cs_*   截面算子，按 date 分组（已内建 .over("date")）
  timeseries      ts_*   日度时序算子，按 code 分组（须 (code,date) 已排序）
  daily           d_*    日度聚合原语：任意 bar 级表达式 -> (code,date) 日值
                         （在 group_by("code","date").agg 中组合使用）
  elementwise            带保护的标量数学（safe_div/s_log/signed_power/round_level）
                         纯加减乘除不包装：polars 表达式原生支持 x+y, x**2
  pressure               日内收益（bar 级，须经 prepare_minute_frame）
  microstructure  _mst_* tick-rule 带号量等微结构原语（bar 级）
  path            _path_* 日内路径定位（bar 级）
  seasonality     _ssn_*  same-minute 基线（bar 级）
  realized               日度已实现矩 / 跳跃分解

原则：**工具 = 可复用原语，场景逻辑由因子文件组合**。Kyle λ / Amihud /
封板时长 / 竞价量占比……都是组合，不是算子（组合示例见 daily.py docstring
与 docs/math-toolbox.md）。准入两扇门见 AGENTS.md；能 Polars 就 Polars，
写不动的（滚动秩、逐 bar 状态机）是 Rust plugin 动工候选。

用法：
    import factor_ops as ops
    df = df.with_columns(ops.ts_delta("close", 5).alias("_mom")) \\
           .with_columns(ops.cs_rank("_mom").alias("alpha"))

注意：cs_* 内建 .over("date")、ts_* 内建 .over("code")，d_* 是 agg 内聚合。
跨分组嵌套（cs_* 套 ts_*、d_* 套 ts_*）**不报错但静默产出全 null**，
必须分步落列。因子整列是 null 时先查这里。elementwise 族（safe_div 等）
不产生分组上下文，不受此限。
"""

from factor_ops.cross_section import (
    cs_daily_spearman,
    cs_demean,
    cs_rank,
    cs_scale,
    cs_winsor,
    cs_zscore,
)
from factor_ops.daily import (
    d_autocorr,
    d_autocov,
    d_beta,
    d_bracket,
    d_corr,
    d_cusum_break,
    d_efficiency_ratio,
    d_frac,
    d_hill,
    d_itersum2,
    d_itersum3,
    d_levy_area,
    d_max_drawdown,
    d_mean,
    d_perm_entropy,
    d_qskew,
    d_quad_coef,
    d_quantile_spread,
    d_share,
    d_sign_entropy,
    d_spearman,
    d_sum,
    d_tail_temper,
    d_theil,
    d_variance_ratio,
    d_wmean,
    tod_between,
)
from factor_ops.elementwise import (
    log_contrast,
    round_level,
    s_log,
    s_sqrt,
    safe_div,
    signed_power,
)
from factor_ops.kernels import hurst_rs, iforest_scores
from factor_ops.microstructure import add_bvc_buy_ratio, add_tick_rule_sv
from factor_ops.path import add_day_path_marks
from factor_ops.pressure import add_ret_1m
from factor_ops.realized import daily_realized_measures
from factor_ops.seasonality import add_same_minute_baseline
from factor_ops.timeseries import (
    ts_argmax,
    ts_argmin,
    ts_baseline,
    ts_corr,
    ts_decay_linear,
    ts_decay_var,
    ts_delay,
    ts_delta,
    ts_fracdiff,
    ts_hawkes,
    ts_max,
    ts_mean,
    ts_min,
    ts_qskew,
    ts_quantile,
    ts_rank,
    ts_std,
    ts_sum,
)

__all__ = [
    "add_bvc_buy_ratio",
    "add_day_path_marks",
    "add_ret_1m",
    "add_same_minute_baseline",
    "add_tick_rule_sv",
    "cs_daily_spearman",
    "cs_demean",
    "cs_rank",
    "cs_scale",
    "cs_winsor",
    "cs_zscore",
    "d_autocorr",
    "d_autocov",
    "d_beta",
    "d_corr",
    "d_bracket",
    "d_cusum_break",
    "d_efficiency_ratio",
    "d_frac",
    "d_hill",
    "d_max_drawdown",
    "d_mean",
    "d_itersum2",
    "d_itersum3",
    "d_levy_area",
    "d_perm_entropy",
    "d_qskew",
    "d_quad_coef",
    "d_quantile_spread",
    "d_share",
    "d_sign_entropy",
    "d_spearman",
    "d_sum",
    "hurst_rs",
    "iforest_scores",
    "d_tail_temper",
    "d_theil",
    "d_variance_ratio",
    "d_wmean",
    "daily_realized_measures",
    "log_contrast",
    "round_level",
    "s_log",
    "s_sqrt",
    "safe_div",
    "signed_power",
    "tod_between",
    "ts_argmax",
    "ts_argmin",
    "ts_baseline",
    "ts_corr",
    "ts_decay_linear",
    "ts_decay_var",
    "ts_delay",
    "ts_delta",
    "ts_fracdiff",
    "ts_hawkes",
    "ts_max",
    "ts_mean",
    "ts_min",
    "ts_qskew",
    "ts_quantile",
    "ts_rank",
    "ts_std",
    "ts_sum",
]
