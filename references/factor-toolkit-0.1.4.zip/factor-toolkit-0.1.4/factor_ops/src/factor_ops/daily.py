"""日度聚合原语 d_*：把任意 bar 级表达式压成 (code, date) 日值。

用法（在 group_by("code", "date").agg(...) 里组合）：

    df.group_by("code", "date").agg(
        amihud=O.d_mean(O.safe_div(pl.col("_prs_ret_1m").abs(), "amount")),
        lam=O.d_beta("_prs_ret_1m", "_mst_sv"),          # Kyle λ（代理）
        ofi=O.d_sum("_mst_sv"),                          # 净主动买压
        seal=O.d_frac(pl.col("close") == pl.col("lim")), # 封板时长占比
        tail_vol=O.d_share("volume", pl.col("is_tail_3m")),
        split_fp=O.d_autocorr("volume", 1),              # 拆单足迹
    )

场景逻辑（封板/竞价/尾盘/拆单…）一律由组合表达，不为场景单设算子。
本族全部是普通聚合表达式：也可加 .over("code","date") 当广播列用。
"""

import math
from datetime import time as time_of_day

import polars as pl


def _e(x: str | pl.Expr) -> pl.Expr:
    return pl.col(x) if isinstance(x, str) else x


def tod_between(start: str | time_of_day, end: str | time_of_day) -> pl.Expr:
    """日内时段掩码 [start, end]（含两端；作用于 dt 列）。

    end-label 口径下："09:31"–"10:00" 是开盘后首个半小时的连续竞价段
    （09:30 是竞价 bar，要含它就从 "09:30" 起）。配 d_share / d_frac /
    .filter 使用，时段端点属于研究口径，进 CARD params。

    例：早盘量异常 = 今晨该段成交量 / 过去 20 日同段基线
        early = O.tod_between("09:31", "10:00")
        day = bars.group_by("code","date").agg(
            v=O.d_sum(pl.col("volume").filter(early)))
        day.sort("code","date").with_columns(
            abn=O.safe_div("v", O.ts_baseline("v", 20)))
    """
    s = time_of_day.fromisoformat(start) if isinstance(start, str) else start
    e = time_of_day.fromisoformat(end) if isinstance(end, str) else end
    t = pl.col("dt").dt.time()
    return (t >= s) & (t <= e)


def d_sum(x: str | pl.Expr) -> pl.Expr:
    return _e(x).sum()


def d_mean(x: str | pl.Expr) -> pl.Expr:
    return _e(x).mean()


def d_wmean(x: str | pl.Expr, w: str | pl.Expr) -> pl.Expr:
    """掩码加权均值：Σ(x·w) / Σ(w | x 有效)。

    权重归一只在 x 非 null 的行上进行——x 的缺失（无该类事件/基线
    未覆盖）不会稀释均值。w 全零或全缺时结果为 null。
    """
    x, w = _e(x), _e(w)
    den = w.filter(x.is_not_null()).sum()
    return pl.when(den > 0).then((x * w).sum() / den).otherwise(None)


def d_frac(cond: pl.Expr) -> pl.Expr:
    """条件成立的 bar 占比（occupation time 的通用形式）。null 不计入分子分母。"""
    return cond.cast(pl.Float64).mean()


def d_share(x: str | pl.Expr, mask: pl.Expr) -> pl.Expr:
    """子时段份额：Σ(x·mask) / Σx（量占比、收益贡献等的通用形式）。"""
    x = _e(x)
    return x.filter(mask).sum() / x.sum()


def d_corr(x: str | pl.Expr, y: str | pl.Expr) -> pl.Expr:
    """日内 pearson 相关（量价相关、背离类的原语）。"""
    return pl.corr(_e(x), _e(y))


def d_beta(y: str | pl.Expr, x: str | pl.Expr) -> pl.Expr:
    """日内回归斜率 cov(y,x)/var(x)（Kyle λ、任意冲击斜率的原语）。"""
    return pl.cov(_e(y), _e(x)) / _e(x).var()


def d_autocov(x: str | pl.Expr, lag: int) -> pl.Expr:
    """日内自协方差（总体口径）：mean[(x_t−x̄)(x_{t−lag}−x̄)]。
    Roll 价差 = 2·sqrt(−d_autocov(r, 1))（cov>0 时无定义，调用方处理）。"""
    x = _e(x)
    xc = x - x.mean()
    return (xc * xc.shift(lag)).mean()


def d_autocorr(x: str | pl.Expr, lag: int) -> pl.Expr:
    """日内自相关（拆单足迹、日内动量结构的原语）。"""
    x = _e(x)
    return pl.corr(x, x.shift(lag))


def _plogp(p: pl.Expr) -> pl.Expr:
    return pl.when(p > 0).then(p * p.log()).otherwise(0.0)


def d_sign_entropy(x: str | pl.Expr) -> pl.Expr:
    """符号香农熵 ∈ [0,1]：x 的 {-,0,+} 三类分布的 H/ln3。

    1 = 三类均匀（最不可预测），0 = 单边（完全规律）。只看符号不看
    幅度——对离群天然免疫（秩性质），描述"规律性"而非"波动"。
    """
    x = _e(x)
    ps = [
        (x < 0).cast(pl.Float64).mean(),
        (x == 0).cast(pl.Float64).mean(),
        (x > 0).cast(pl.Float64).mean(),
    ]
    h = -sum((_plogp(p) for p in ps), start=pl.lit(0.0))
    return h / math.log(3)


def d_perm_entropy(x: str | pl.Expr) -> pl.Expr:
    """排列熵（阶数 m=3，Bandt-Pompe 2002），归一化到 [0,1]。

    把相邻三元组 (x_{t-2}, x_{t-1}, x_t) 按大小关系归入 6 种序型，
    对序型分布取 H/ln6。0 = 单一序型（如单调日），1 = 六型均匀
    （最大复杂度）。排列敏感（过程信息）、幅度免疫。tie 以严格 <
    判序（并入 ≥ 分支）。一般阶数 m 的版本是 🦀 Rust 候选。
    """
    c = _e(x)
    a, b = c.shift(2), c.shift(1)
    code = (
        (a < b).cast(pl.Int8) * 4 + (a < c).cast(pl.Int8) * 2 + (b < c).cast(pl.Int8)
    )
    # 8 个编码中 2 个违反传递性、频率恒为 0，参与求和无害
    h = -sum(
        (_plogp((code == v).cast(pl.Float64).mean()) for v in range(8)),
        start=pl.lit(0.0),
    )
    return h / math.log(6)


def d_theil(x: str | pl.Expr) -> pl.Expr:
    """Theil-T 集中度指数 = Σ pᵢ·ln(pᵢ·n)，pᵢ = xᵢ/Σx，n = 非空 bar 数（Theil 1967）。

    度量"分布有多集中在少数 bar"：0 = 完全均匀（每 bar 等量），ln(n) = 全挤在一根。
    与香农熵关系 = ln(n) − H(p)。x 须 ≥0（量/份额类）；Σx≤0 或 n<2 → null。
    reference：均匀 x →0；单点 x=(1,0,…,0) → ln(n)。零值 bar（pᵢ=0）贡献 0。
    """
    x = _e(x)
    n = x.count()
    p = x / x.sum()
    return (
        pl.when((x.sum() > 0) & (n >= 2))
        .then(pl.when(p > 0).then(p * (p * n).log()).otherwise(0.0).sum())
        .otherwise(None)
    )


def d_spearman(x: str | pl.Expr, y: str | pl.Expr) -> pl.Expr:
    """日内秩相关(Spearman)= pearson(rank x, rank y)。捕捉单调**非线性**量价关系——
    d_corr 只测线性。reference:spearman(x, x³)=1 而 pearson<1。"""
    return pl.corr(_e(x).rank(), _e(y).rank())


def d_qskew(x: str | pl.Expr) -> pl.Expr:
    """Bowley 分位偏度 =(Q75+Q25−2·Q50)/(Q75−Q25) ∈ [−1,1]。稳健 skew——
    矩偏度(rskew)厚尾下脆,本算子只用分位、对离群免疫。对称分布=0;Q75=Q25→null。"""
    x = _e(x)
    q1, q2, q3 = x.quantile(0.25), x.quantile(0.5), x.quantile(0.75)
    return pl.when(q3 > q1).then((q3 + q1 - 2 * q2) / (q3 - q1)).otherwise(None)


def d_quantile_spread(x: str | pl.Expr, q: float = 0.25) -> pl.Expr:
    """分位距 = Q(1−q) − Q(q)。稳健离散度(替 std,厚尾下不被离群劫持)。
    q=0.25 即 IQR。reference:U[0,1], q=0.25 → ≈0.5。"""
    x = _e(x)
    return x.quantile(1 - q) - x.quantile(q)


def d_efficiency_ratio(p: str | pl.Expr) -> pl.Expr:
    """Kaufman 效率比 = |p_last − p_first| / Σ|Δp| ∈ [0,1]。趋势 vs 来回磨:
    1 = 单调直线(纯趋势),0 = 反复震荡净移动为 0。须按 dt 有序输入;Σ|Δp|=0→null。
    reference:单调序列→1,纯锯齿(净0)→0。"""
    p = _e(p)
    path = p.diff().abs().sum()
    return pl.when(path > 0).then((p.last() - p.first()).abs() / path).otherwise(None)


def d_max_drawdown(p: str | pl.Expr) -> pl.Expr:
    """日内最大回撤 = min(p / cummax(p) − 1) ≤ 0(峰到谷最大跌幅,负数)。
    须按 dt 有序、p>0。reference:[1,2,1.5] → −0.25;单调升 → 0。"""
    p = _e(p)
    return (p / p.cum_max() - 1).min()


def d_variance_ratio(ret: str | pl.Expr, k: int = 2) -> pl.Expr:
    """Lo-MacKinlay 方差比 = Var(k 步滚动和) /(k · Var(1 步))。>1 趋势(正自相关)、
    <1 均值回复、≈1 随机游走。日内 ret 序列、按 dt 有序;Var=0→null。
    reference:iid → ≈1。"""
    r = _e(ret)
    return pl.when(r.var() > 0).then(r.rolling_sum(k).var() / (k * r.var())).otherwise(None)


def d_hill(x: str | pl.Expr, k: int) -> pl.Expr:
    """Hill 尾指数（Hill 1975）：α̂ = [mean(ln x_(i) − ln x_(k+1))]⁻¹，
    取 |x| 最大的 k 个对第 k+1 个。

    α 越小尾越肥（崩盘/博彩性越强）。k 是偏差-方差权衡（研究口径，
    进 CARD params）；日内 240 根下 k 取 10~20 量级。
    """
    t = _e(x).abs().top_k(k + 1).log()
    return 1.0 / (t.head(k).mean() - t.min())


def d_tail_temper(x: str | pl.Expr, k_inner: int, k_outer: int) -> pl.Expr:
    """尾部缓和度 = Hill(深尾 k_outer) − Hill(浅尾 k_inner),须 k_outer < k_inner。

    Hill 尾指数 α̂ 随取样深度的变化(Hill plot 斜率):纯幂律(Pareto)各深度 α̂ 恒定 → ≈0;
    tempered(远尾比幂律更薄、朝有限截断弯,Carr-Geman-Madan-Yor 2002)→ 深尾 α̂ 更大 → >0;
    反向(远尾更肥,临界/爆发)→ <0。描述极端值是"封顶饱和(稳)"还是"失控(脆)"。

    在输入的**上尾**估计(Hill 需正的超出量):上尾传 ret、下尾传 −ret、双尾传 |ret|;
    左右分开传即得不对称缓和。只用序统计量、与 bar 顺序无关。须 k_outer < k_inner < n,
    调用方按 bar 数 gate。理论锚:Hill(1975)尾指数 + Hill-plot 深度依赖诊断幂律偏离。
    reference:Hill plot 平(纯幂律)→ ≈0;远尾被拉回变薄 → >0;远尾爆开变肥 → <0;顶部并列(退化)→ null。
    """
    xe = _e(x)
    ti = xe.top_k(k_inner + 1).log()                       # 浅尾:最大 k_inner+1 个(降序)
    to = xe.top_k(k_outer + 1).log()                       # 深尾:最大 k_outer+1 个
    di = ti.head(k_inner).mean() - ti.min()                # log 间距=Hill 分母;顶部并列→0
    do = to.head(k_outer).mean() - to.min()
    hill_inner = pl.when(di > 1e-6).then(1.0 / di).otherwise(None)  # 退化→null,不发 inf
    hill_outer = pl.when(do > 1e-6).then(1.0 / do).otherwise(None)
    return hill_outer - hill_inner


def d_quad_coef(y: str | pl.Expr, t: str | pl.Expr) -> pl.Expr:
    """二次项系数 c：最小二乘拟合 y ~ a + b·t + c·t² 的曲率项（闭式正规方程）。

    c>0 凸（加速），c<0 凹（衰竭）。中心化 τ = t − mean(t) 解三阶正规方程：
        c = (S2·Y2 − S2²·Y0 − S3·Y1) / (S2·S4 − S2³ − S3²)
    其中 S_k = mean(τ^k)、Y_k = mean(y·τ^k)。点数 < 3 或共线时分母→0 得 inf/null，
    由调用方按 bar 数 gate。幅度随 t、y 单位缩放（截面 rank 用，绝对值不可跨样本比）。
    理论锚：多项式最小二乘（正规方程），离散曲率的二阶投影。
    """
    y, t = _e(y), _e(t)
    tau = t - t.mean()
    s2 = (tau**2).mean()
    s3 = (tau**3).mean()
    s4 = (tau**4).mean()
    y0 = y.mean()
    y1 = (y * tau).mean()
    y2 = (y * tau**2).mean()
    return (s2 * y2 - s2**2 * y0 - s3 * y1) / (s2 * s4 - s2**3 - s3**2)


def d_cusum_break(x: str | pl.Expr) -> pl.Expr:
    """CUSUM 变点位置（占比 ∈ [0,1]）：累积去均值和 C_i = Σ_{j≤i}(x_j − x̄)
    的 |C| 最大处序号 / 序列长度。

    标准均值漂移变点检测（Page 1954 的 CUSUM）：序列均值发生最显著一次漂移的
    时点。返回相对位置，早=小、晚=大。决断度（max|C| 的幅度）另由调用方按需取
    `(x − x.mean()).cum_sum().abs().max()` 归一。长度 < 2 时无意义，调用方 gate。
    """
    x = _e(x)
    return (x - x.mean()).cum_sum().abs().arg_max() / x.len()


# ---- 签名/迭代和族(Chen iterated sums / Lévy 面积 / 跳跃括号)------------
# 离散(纯跳)流的 forward/Itô 签名 = iterated sums;Marcus 签名 = 补 ½ 跳跃平方
# 修正(= d_itersum2 + 0.5·d_bracket,不设独立算子)。参考:Chen 1957;
# Noguer i Alonso 2026 (arXiv:2606.28869) §4-5。输入一律为**增量列**(bar 级 δ,
# 组内按行序累积——调用方须先按 dt 排好序;null 增量按 0 计)。
# 厚尾注意(§0b):二次型,幅度归一由因子文件负责(量份额/log 增量/safe_div)。


def d_itersum2(dx: str | pl.Expr, dy: str | pl.Expr) -> pl.Expr:
    """二阶迭代和 S_xy = Σ_{k<l} δx_k·δy_l(Itô/forward 签名的 level-2 坐标)。"""
    x, y = _e(dx).fill_null(0.0), _e(dy).fill_null(0.0)
    return (y * (x.cum_sum() - x)).sum()


def d_bracket(dx: str | pl.Expr, dy: str | pl.Expr) -> pl.Expr:
    """跳跃二次协变差 [x,y] = Σ δx·δy —— Itô 签名对 shuffle 恒等式的缺口
    (恒等式:S_x·S_y = S_xy + S_yx + [x,y],即论文 Prop 4.3 式18)。"""
    return (_e(dx).fill_null(0.0) * _e(dy).fill_null(0.0)).sum()


def d_levy_area(dx: str | pl.Expr, dy: str | pl.Expr) -> pl.Expr:
    """Lévy 面积 A_xy = ½(S_xy − S_yx):二阶**反对称**签名坐标——"谁先谁后"。

    A>0 = x 的累积领先 y(x 先动、y 跟)。与 d_corr(对称,"是否同动")正交的信息
    维度;双通道 Hawkes 互激方向的一阶统计量(同论文 §10)。A_xy ≡ −A_yx。"""
    x, y = _e(dx).fill_null(0.0), _e(dy).fill_null(0.0)
    return 0.5 * ((y * (x.cum_sum() - x)).sum() - (x * (y.cum_sum() - y)).sum())


def d_itersum3(dx: str | pl.Expr, dy: str | pl.Expr, dz: str | pl.Expr) -> pl.Expr:
    """三阶迭代和 S_xyz = Σ_{k<l<m} δx_k·δy_l·δz_m(签名 level-3 坐标,词=xyz)。

    嵌套构造:S_xy 的逐行前缀和再与 δz 配对——纯表达式,零循环。
    Level-3 开始描述"领先是**怎样形成**的"(渐进 vs 脉冲、发生在何时),
    而非仅"有没有领先"(level-2 面积)。厚尾注意:三次型,输入必须先归一。"""
    x, y, z = _e(dx).fill_null(0.0), _e(dy).fill_null(0.0), _e(dz).fill_null(0.0)
    c2 = y * (x.cum_sum() - x)            # 第 l 行:δy_l · S_x(<l)
    return (z * (c2.cum_sum() - c2)).sum()  # 第 m 行:δz_m · S_xy(<m)
