# factor_ops

公共算子库——因子 = 算子的组合。

## 使用

```python
import factor_ops as ops
import polars as pl

# 截面秩 + 时序差分
# cs_* 内建 .over("date")、ts_* 内建 .over("code")，跨分组嵌套
# （如 cs_rank(ts_delta(...))）不报错但静默产出全 null，必须分步落列
df = df.with_columns(
    _mom=ops.ts_delta("close", 5)
).with_columns(
    alpha=ops.cs_rank("_mom")
)

# 日度聚合
bars.group_by("code", "date").agg(
    amihud=ops.d_mean(ops.safe_div(pl.col("ret").abs(), "amount"))
)
```

## 算子分类

- `cs_*`：截面算子（cross_section）
- `ts_*`：时序算子（timeseries）
- `d_*`：日度聚合原语（daily）
- `safe_div`, `s_log` 等：带保护的标量数学（elementwise）
- `add_bvc_buy_ratio`, `add_tick_rule_sv` 等：微结构原语（microstructure）
