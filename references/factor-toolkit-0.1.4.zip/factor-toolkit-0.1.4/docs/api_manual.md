# factor-toolkit API 手册

**factor_ops 0.1.4 · factor_eval 0.1.4 · Python 3.10+ · Polars 1.21+**

两个包的完整接口文档：

| 包 | 干什么 |
|---|---|
| `factor_ops` | 算子库。截面 / 时序 / 日内聚合 / 微结构原语，因子 = 算子的组合 |
| `factor_eval` | 评价器。IC、分组阶梯、多空、头部分层、衰减、尾部诊断 + PDF 报告 |

**数据是你自己的。** 本手册只讲这些函数要求你传什么、返回什么。第 1 节的"契约"是
**函数的前置条件**（哪些列、什么排序），不是对任何特定数据源的规范——行情从哪来、
收益标签怎么算，都由你决定。

底层是 [Polars](https://pola.rs)，不是 pandas。

---

## 0. 五分钟上手

你要做的事只有一件：**写一个因子，看它有没有用。**

1. 造一张因子表：`date / code / factor_value`
2. 造一张远期收益表：`date / code / fwd_ret`
3. 丢给 `evaluate`，看报告

```python
import polars as pl
import factor_ops as ops
from factor_eval import evaluate, report_pdf

# daily: 你自己的日线表，至少含 date / code / close，按 (code, date) 排序
daily = pl.read_parquet("your_daily_bars.parquet").sort("code", "date")

# 1. 造因子 —— 这里是你要替换的部分。输出必须是 date/code/factor_value 三列
#    ts_ 与 cs_ 不能直接套（见 2.0 节「嵌套规则」），必须分两步落列
factor = (
    daily.with_columns(ops.ts_delta("close", 5).alias("_mom5"))
         .with_columns(ops.cs_rank("_mom5").alias("factor_value"))
         .select("date", "code", "factor_value")
         .drop_nulls()
)

# 2. 造标签 —— T 日出信号，T+1 的收益
labels = (
    daily.with_columns(
        (pl.col("close").shift(-1) / pl.col("close") - 1).over("code").alias("fwd_ret")
    )
    .select("date", "code", "fwd_ret")
    .drop_nulls()
)

# 3. 评价 + 出报告
rep = evaluate(factor, labels, n_groups=20)
print(rep)                                    # 一行摘要
report_pdf(rep, "my_factor.pdf", name="my_factor")
```

看 `print(rep)` 的第一行：`IC mean` 是否显著（`t` 绝对值 > 2）、`mono` 是否接近 ±1
（分组是否单调），基本就能判断因子有没有用。字段含义见 3.2 节。

**想评价 T+5**：把对应周期的收益列改名成 `fwd_ret`，并告诉评价器持有期：

```python
labels5 = (daily.with_columns(
               (pl.col("close").shift(-5) / pl.col("close") - 1).over("code").alias("fwd_ret"))
           .select("date", "code", "fwd_ret").drop_nulls())
rep5 = evaluate(factor, labels5, n_groups=20, overlap_h=5)   # ← 这个参数别忘
```

`overlap_h` 不填的话，重叠持有期会让 t 值虚高（因子换手越慢虚高越多），点估计不受影响。

> 没有真实数据也能先跑通：包里 `examples/make_demo_data.py` 会生成一份合成面板，
> `examples/quickstart.py` 是完整的端到端示例。

---

## 1. 接口契约

所有函数都工作在 Polars DataFrame / LazyFrame 上。核心约定三条：**键唯一、排好序、列名固定**。

下面每张表说的是**某族函数要求你的 DataFrame 长什么样**。你的数据来自哪里、
经过了什么清洗，这些函数一概不管，也不检查——它们只做统计。

> **对齐和无前视是你的责任。** 评价器不会检查你的因子有没有用到未来信息。
> 用 T 日盘中数据算出的因子去对齐 T 日入场的收益，就是前视，结果会明显虚高。

### 1.1 日频表 —— `ts_*` / `cs_*` 的输入

一只股票一行一天：

| 列 | 类型 | 说明 |
|---|---|---|
| `code` | Utf8 | 股票代码（或任意标的 id） |
| `date` | Date | 交易日 |
| `open` / `high` / `low` / `close` | Float64 | 行情价（用到哪列传哪列，不是全都必需） |
| `volume` / `amount` | Float64 | 成交量 / 成交额 |

约定：

- **`(code, date)` 必须唯一**，且全表**已按 `(code, date)` 升序排序**。
  `ts_*` 时序算子对乱序输入**产出错值而不是报错**。
- 额外的因子列、标签列直接往后加即可。
- 只有你实际调用的算子用到的列才是必需的。`cs_rank("close")` 只要 `date` 和 `close`。

### 1.2 bar 级表 —— `d_*` / `add_*` / kernels 的输入

`microstructure` / `pressure` / `path` / `seasonality` / `daily` 这几族的输入：

| 列 | 类型 | 说明 |
|---|---|---|
| `code` | Utf8 | 标的代码 |
| `dt` | Datetime | bar 时间戳 |
| `date` | Date | 所属交易日（= `dt` 的日期部分） |
| `open` / `high` / `low` / `close` / `volume` / `amount` | Float64 | bar 行情 |

约定：**已按 `(code, dt)` 升序排序**，且**必须带 `date` 列**（很多函数按 `(code, date)`
分组，不能只靠 `dt`）。

> 源码注释里反复出现的 `prepare_minute_frame` **不是本包提供的函数**，它只是上面这条
> 数据准备约定的名字。把你的分钟数据整理成"按 `(code, dt)` 排序 + 带 `date` 列"的
> LazyFrame，就可以直接调用所有 bar 级函数。

频率不限于 1 分钟——5 分钟、tick 聚合都行，只是部分函数的参数量级要相应调整
（如 `d_hill(x, k)` 的 `k`）。

### 1.3 因子表 —— `evaluate` 的输入一

| 列 | 类型 | 说明 |
|---|---|---|
| `date` / `code` | Date / Utf8 | 键，`(date, code)` 必须唯一 |
| `factor_value` | Float64 | 因子值。**方向随意**，评价器自动定方向 |

### 1.4 远期收益表 —— `evaluate` 的输入二

| 列 | 类型 | 说明 |
|---|---|---|
| `date` / `code` | Date / Utf8 | 键，唯一 |
| `fwd_ret` | Float64 | **主口径**远期收益 |
| `fwd_ret_2` / `_5` / `_10` … | Float64 | 可选，多持有期。列名必须是 `fwd_ret_<整数>`，自动产出 IC decay |

`date` 的语义由你定，但**必须和因子表一致**。最常见的两种约定：

| 约定 | `date` 的含义 | 因子能用到什么信息 |
|---|---|---|
| **信息截止日**（推荐） | T = 因子算完的那天，T+1 入场 | T 日收盘及之前的全部数据 |
| **入场日** | T = 实际买入那天（如开盘成交） | 只能用 T-1 收盘之前 + T 日开盘前的信息 |

用第二种约定时特别容易前视：因子若用了 T 日盘中或全天数据，再对齐 `date=T` 的收益，
就是偷看未来。只用日线的因子，最稳妥的做法是照常按"信息截止日"算，再把 `date`
往后挪一个交易日对齐。

典型构造（T 日收盘出信号、T+1 收盘计价）：

```python
labels = daily.sort("code", "date").with_columns(
    (pl.col("close").shift(-1) / pl.col("close") - 1).over("code").alias("fwd_ret"),
    (pl.col("close").shift(-5) / pl.col("close") - 1).over("code").alias("fwd_ret_5"),
    (pl.col("close").shift(-10) / pl.col("close") - 1).over("code").alias("fwd_ret_10"),
)
```

> 收益该用收盘价、VWAP 还是开盘价，要不要剔除当日涨停/停牌不可买的样本——
> 这些都是你的口径选择。评价器只认最后这张表。**不可交易的样本建议先过滤掉**，
> 留着会把评价结果做虚。

### 1.5 `evaluate` 的可选输入

| 参数 | 列 | 说明 |
|---|---|---|
| `benchmark` | `date` / `bench_ret` | 基准日收益。不传则退化为**评测票池等权**（兜底口径，正式结论应传真基准）。**样本日缺基准直接报错** |
| `sectors` | `date` / `code` / `sector` | 行业，产出分行业 IC（日内组内 ≥5 只才计） |
| `mkt_cap` | `date` / `code` / `mkt_cap` | 市值，产出市值五分位 IC（Q1 小 → Q5 大） |

---

## 2. factor_ops：算子库

```python
import factor_ops as ops
```

> **这些算子只是便利工具，不是必须用的。** 它们把常用写法（截面排名、滚动统计、
> 日内聚合……）打包好省得重写，口径也统一。但你完全可以**不用它们，直接用 polars
> 从零写自己的因子逻辑**——`factor_ops` 只是可选的加速器。`evaluate` 只认最终的
> `date / code / factor_value` 三列，不关心中间怎么算出来的。

本节 64 个算子分两半：

- **只吃日频表的**：`cs_*`（2.2）、`ts_*`（2.3）、elementwise（2.1）、kernels（2.6）——共 32 个。
- **需要 bar 级数据的**：`d_*`（2.4）、`add_*`（2.5）、`daily_realized_measures`——共 32 个。
  没有分钟/tick 数据的话，这两族可以整段跳过。

算子分两类：

- **表达式算子**（绝大多数）：输入列名或 `pl.Expr`，返回 `pl.Expr`，用在 `with_columns` /
  `select` / `group_by().agg()` 里。null 不参与统计、原位保留。**嵌套有限制，见 2.0。**
- **frame 级算子**（`add_` 前缀及少数特例）：输入 LazyFrame，返回加了新列的 LazyFrame。

统一纪律：滚动窗口默认**最严格口径**（不足窗口 = null），放宽必须显式传 `min_samples`；
噪声参数（window、seed 等）多为 keyword-only 且无默认值，必须显式传。

### 2.0 嵌套规则（重要，踩了不报错）

`cs_*` 内建 `.over("date")`、`ts_*` 内建 `.over("code")`，`d_*` 是 `agg()` 里的聚合。

> **跨分组嵌套会静默产出全 null，不会报错。**
> 因子结果整列是 null 时，第一个要怀疑的就是这里。

危险的是**外层按 date、内层按 code**（或 `d_*` 聚合里套 `ts_*`）这种分组冲突：

| 组合 | 结果 | 例 |
|---|---|---|
| **cs_\*** 套 **ts_\*** | **静默全 null** ⚠️ | `cs_rank(ts_delta("close", 5))` |
| **d_\*** 套 **ts_\*** | **静默全 null** ⚠️ | `d_mean(ts_delta("close", 1))` |
| elementwise 互相嵌套 | 正常 | `safe_div(s_log("close"), "amount")` |
| 任意算子套 elementwise | 正常 | `cs_rank(safe_div("close", "amount"))` |
| elementwise 套 **cs_\*** / **ts_\*** | 正常 | `safe_div("volume", ts_baseline("volume", 20))` |
| 同分组嵌套（cs 套 cs、ts 套 ts） | 正常 | `cs_rank(cs_zscore("close"))` |
| **ts_\*** 套 **cs_\*** | 正常 | `ts_delta(cs_rank("close"), 1)` |

elementwise 族指 `safe_div` / `s_log` / `s_sqrt` / `signed_power` / `log_contrast` /
`round_level`（2.1 全族），它们不带 `.over`，不产生分组上下文。

**建议一律分步落列**——上表后四行虽然当前可用，但依赖 Polars 的窗口求值细节，
升级版本可能变。分步写法在任何版本下语义都确定：

```python
# ⚠️ 不报错，但 f 整列是 null
daily.with_columns(ops.cs_rank(ops.ts_delta("close", 5)).alias("f"))

# ✓ 先把 ts_ 结果落成中间列，再做截面
daily.with_columns(ops.ts_delta("close", 5).alias("_mom")) \
     .with_columns(ops.cs_rank("_mom").alias("f"))
```

### 2.1 elementwise：带保护的标量数学

纯加减乘除、平方、abs 不包装（Polars 原生支持）。本族只收"裸算术有陷阱"的：

| 函数 | 说明 |
|---|---|
| `safe_div(a, b)` | 除法，b == 0 → null（不是 inf，防毒化下游） |
| `s_log(x)` | log，x <= 0 → null |
| `s_sqrt(x)` | 开方，x < 0 → null |
| `signed_power(x, a)` | sign(x)·\|x\|^a（压幅保号，a<1 抑制极端值） |
| `log_contrast(a, b)` | log(1+a) − log(1+b)，双边机制对比构造 |
| `round_level(price, step)` | 最近的整数关口价 round(p/step)·step |

### 2.2 cross_section（`cs_*`）：截面算子

同一交易日全市场横截面变换，分组 `.over("date")` 已内建，框架须含 `date` 列。

| 函数 | 说明 |
|---|---|
| `cs_rank(x)` | 截面百分位秩 ∈ (0, 1]（Alpha101 的 rank，tie 取平均秩） |
| `cs_zscore(x)` | 截面 z-score |
| `cs_demean(x)` | 截面去均值 |
| `cs_scale(x, a=1.0)` | L1 归一：Σ\|x\| = a |
| `cs_winsor(x, q=0.01)` | 截面分位截尾，压到 [q, 1−q] 分位内 |
| `cs_daily_spearman(df, x, y)` | **frame 级**：日度截面 spearman 的均值，返回 float（对账标准件） |

### 2.3 timeseries（`ts_*`）：日度时序算子

每只票自身日度序列上的变换，分组 `.over("code")` 已内建。**输入必须 `(code, date)` 已排序。**

| 函数 | 说明 |
|---|---|
| `ts_delay(x, d)` | d 日前的值 |
| `ts_delta(x, d)` | 当前值 − d 日前的值 |
| `ts_mean` / `ts_std` / `ts_sum` / `ts_min` / `ts_max(x, w, min_samples=None)` | 滚动统计 |
| `ts_quantile(x, w, q, min_samples=None)` | 滚动第 q 分位 |
| `ts_qskew(x, w, min_samples=None)` | Bowley 分位偏度 ∈ [−1,1]，厚尾稳健的偏度 |
| `ts_corr(x, y, w)` | 滚动 pearson 相关 |
| `ts_decay_linear(x, w, min_samples=None)` | 线性衰减加权均值，近日权重最大 |
| `ts_baseline(x, w, min_samples=None)` | 截至**昨日**的 w 日滚动均值（基线/尺子语义：当期值不进自己的基线，供"今日值 / 历史正常水平"比较） |
| `ts_hawkes(x, decay)` | Hawkes 自激强度（指数核 IIR 递归），decay=exp(−β) ∈ [0,1) |
| `ts_fracdiff(x, d, window)` | 分数阶差分（FFD 固定窗口）；输入须无 null |
| `ts_rank(x, w)` | 当前值在过去 w 日窗口内的百分位秩（严格满窗才出值） |
| `ts_argmax` / `ts_argmin(x, w)` | 过去 w 日最大/最小值的位置，1..w（1=最旧，w=当天，并列取最旧） |
| `ts_decay_var(frame, value_col, decay_col, *, group="code", date_col="date", out_col="_rp")` | **frame 级**：时变衰减运行均值（Grinblatt-Han 参考价），decay_col 须已 clip 到 [0,1]，返回 frame + out_col |

### 2.4 daily（`d_*`）：bar 级 → (code, date) 日值

在 `group_by("code", "date").agg(...)` 里组合使用，把任意 bar 级表达式压成日值。
也可加 `.over("code","date")` 当广播列。

```python
day = bars.group_by("code", "date").agg(
    amihud=ops.d_mean(ops.safe_div(pl.col("_prs_ret_1m").abs(), "amount")),
    lam=ops.d_beta("_prs_ret_1m", "_mst_sv"),             # Kyle λ（代理）
    ofi=ops.d_sum("_mst_sv"),                             # 净主动买压
)
```

| 函数 | 说明 |
|---|---|
| `tod_between(start, end)` | 日内时段掩码 [start, end]，作用于 `dt` 列（如 "09:31"–"10:00"） |
| `d_sum` / `d_mean(x)` | 求和 / 均值 |
| `d_wmean(x, w)` | 掩码加权均值：权重归一只在 x 非 null 的行上进行 |
| `d_frac(cond)` | 条件成立的 bar 占比（occupation time） |
| `d_share(x, mask)` | 子时段份额：mask 命中部分的 Σx / 全天 Σx。**mask 必须是布尔条件表达式**（内部走 `filter`，传数值列会报 SchemaError） |
| `d_corr(x, y)` | 日内 pearson 相关 |
| `d_spearman(x, y)` | 日内秩相关（捕捉单调非线性） |
| `d_beta(y, x)` | 日内回归斜率 cov(y,x)/var(x)（Kyle λ 等冲击斜率原语） |
| `d_autocov(x, lag)` | 日内自协方差（Roll 价差 = 2·sqrt(−d_autocov(r,1))） |
| `d_autocorr(x, lag)` | 日内自相关（拆单足迹、日内动量结构） |
| `d_sign_entropy(x)` | 符号香农熵 ∈ [0,1]，只看符号不看幅度 |
| `d_perm_entropy(x)` | 排列熵（m=3，Bandt-Pompe），归一化 [0,1] |
| `d_theil(x)` | Theil-T 集中度：分布多集中在少数 bar；x 须 ≥ 0 |
| `d_qskew(x)` | 日内 Bowley 分位偏度 ∈ [−1,1] |
| `d_quantile_spread(x, q=0.25)` | 分位距 Q(1−q) − Q(q)，稳健离散度 |
| `d_efficiency_ratio(p)` | Kaufman 效率比 ∈ [0,1]，1=纯趋势，0=来回磨；须按 dt 有序 |
| `d_max_drawdown(p)` | 日内最大回撤 ≤ 0；须按 dt 有序、p>0 |
| `d_variance_ratio(ret, k=2)` | Lo-MacKinlay 方差比：>1 趋势、<1 均值回复、≈1 随机游走 |
| `d_hill(x, k)` | Hill 尾指数 α（越小尾越肥），240 根下 k 取 10~20 量级 |
| `d_tail_temper(x, k_inner, k_outer)` | 尾部缓和度 = Hill(深尾) − Hill(浅尾)，须 k_outer < k_inner |
| `d_quad_coef(y, t)` | 二次拟合 y ~ a + b·t + c·t² 的曲率项 c |
| `d_cusum_break(x)` | CUSUM 变点相对位置 ∈ [0,1] |
| `d_itersum2(dx, dy)` | 二阶迭代和（签名 level-2），输入为增量列、组内按行序 |
| `d_bracket(dx, dy)` | 跳跃二次协变差 Σ δx·δy |
| `d_levy_area(dx, dy)` | Lévy 面积：二阶反对称签名坐标，"谁先谁后"（A>0 = x 领先 y） |
| `d_itersum3(dx, dy, dz)` | 三阶迭代和（签名 level-3），输入须先归一 |

### 2.5 bar 级标注（`add_*`，frame 级）

输入 1.2 节的 bar 级表，输出加列后的 LazyFrame。各族的列命名空间固定。

| 函数 | 产出列 | 说明 |
|---|---|---|
| `add_ret_1m(lf)` | `_prs_ret_1m` | bar 收益 close/前一根close − 1，按 (code,date) 分组，每日首根为 null，绝不跨日串价 |
| `add_tick_rule_sv(lf)` | `_mst_sv` | tick-rule 带号成交量 sign(Δclose)·volume（价格不动沿用上一非零符号）。1min 粒度方向误判约 2-3 成：估计值向零衰减但**保序**——截面 rank 后可用，绝对值不可跨期比 |
| `add_bvc_buy_ratio(lf, *, sigma_window, min_samples, clip)` | `_mst_buy_ratio`, `_mst_bvc_sv` | BVC 买量分类（比 tick-rule 平滑）。买量 = volume·`_mst_buy_ratio`；净买 = `_mst_bvc_sv`。同为保序代理 |
| `add_day_path_marks(lf)` | `_path_bar_idx`, `_path_n_bars`, `_path_low_idx`, `_path_high_idx`, `_path_since_low` | 日内路径定位（当日第几根、最低/最高点所在 bar、相对低点的位移），tie 取最早 |
| `add_same_minute_baseline(lf, *, value_col, baseline_window_days, min_samples, stat="mean")` | `_ssn_base_<col>` | same-minute 基线：同一 (code, 分钟) 在过去 N 日的滚动 mean/median。先 shift(1) 再 rolling，当日绝不进自己的基线；肥尾比值类必须用 `stat="median"`。value_col 可传列表，多列单遍计算 |
| `daily_realized_measures(lf, *, ret_col, min_obs)` | (code, date) 日表 | 已实现矩：n_ret / rv / bpv / jv / rs_neg / rs_pos / signed_jump / rskew / rkurt；有效收益数 < min_obs 整行指标置 null |

### 2.6 kernels：整段序列核（`map_elements` 用）

无法写成 Polars 表达式的序列逻辑。用法：`group_by(code,date).agg(_l=pl.col(...))`
拿到 list 列后 `map_elements`。

| 函数 | 说明 |
|---|---|
| `hurst_rs(values)` | R/S Hurst 指数 ∈ [0,1]：≈0.5 随机游走，>0.5 趋势持续，<0.5 均值回复。输入一日内价格序列，有效点 <10 → None |
| `iforest_scores(x, *, n_estimators, seed)` | Isolation Forest 截面异常度（输入 (n≥10, k) 特征矩阵），越大越异常；纯截面无监督、无前视，固定 seed 确定性 |

### 2.7 组合示例

```python
import polars as pl
import factor_ops as ops

# 日频因子：5 日动量的截面秩
# ts_ 与 cs_ 都是窗口表达式，不能直接套（见 2.0），必须分步落列
factor = daily.sort("code", "date").with_columns(
    ops.ts_delta("close", 5).alias("_mom")
).with_columns(
    ops.cs_rank("_mom").alias("factor_value")
).select("date", "code", "factor_value").drop_nulls()

# 量异：今日成交量 / 过去 20 日基线（注意用 ts_baseline，不是 ts_mean）
factor2 = daily.sort("code", "date").with_columns(
    ops.safe_div("volume", ops.ts_baseline("volume", 20)).alias("factor_value")
).select("date", "code", "factor_value").drop_nulls()

# bar 级：分钟数据 → Amihud 非流动性日值
bars2 = ops.add_ret_1m(bars)
amihud = bars2.group_by("code", "date").agg(
    ops.d_mean(ops.safe_div(pl.col("_prs_ret_1m").abs(), "amount")).alias("factor_value")
)
```

---

## 3. factor_eval：因子评价器

```python
from factor_eval import evaluate, report_pdf
```

一个函数一张报告，**不是回测系统**。所有因子过同一套指标（分组固定 20 组、
成本固定双边 15bp、年化按 244 交易日），结论才可比。

### 3.1 evaluate：评价主入口

```python
rep = evaluate(
    factor,          # 1.3 节因子表：date / code / factor_value
    fwd_ret,         # 1.4 节收益表：date / code / fwd_ret [+ fwd_ret_<h>...]
    *,
    n_groups=20,     # 分组数，<20 直接报错（统一尺子）
    benchmark=None,  # 可选：date / bench_ret
    sectors=None,    # 可选：date / code / sector
    mkt_cap=None,    # 可选：date / code / mkt_cap
    overlap_h=1,     # 主标签持有天数；>1 时全部 t/p 走 Newey-West 校正
)
print(rep)           # 一行摘要：IC / 分组 / L/S / 头部 / 尾部 / decay
```

输入校验（不满足直接抛 `ContractError`）：必需列缺失、`(date, code)` 键重复、
factor 为空、配对后无有效样本、benchmark 缺样本日。

`ContractError` 可从 `factor_eval` 直接导入。

### 3.2 EvalReport：返回内容

**标量统计**

| 字段 | 含义 |
|---|---|
| `n_obs` / `n_dates` / `coverage` | 样本数 / 可计算 IC 的日期数 / 因子行配上收益的比例 |
| `ic_mean` / `ic_std` / `icir` / `ic_tstat` / `ic_pvalue` | 日度 spearman IC 的均值、波动、ICIR、t、双侧 p |
| `ic_skew` / `ic_kurtosis` / `ic_pos_rate` | IC 分布形态与 IC>0 占比 |
| `monotonicity` | 分组序号 vs 组均收益的 spearman（越接近 ±1 越单调） |
| `long_short_mean` / `long_short_tstat` / `ls_alpha` / `ls_beta` / `ls_sharpe` / `ls_max_drawdown` | 顶组−底组多空（按 direction 定向） |
| `rank_autocorr` | 相邻日因子秩自相关（换手的反面） |
| `direction` | +1 = 高因子值为多头侧；−1 = 低因子值。跟随**可交易端点谱**（顶底组原始收益差）而非 sign(IC) |
| `non_monotone` | True = IC（主体）与端点谱（尾部）符号矛盾，定向存疑 |
| `tail_gradient_top` / `tail_gradient_bottom` | 顶/底尾信息浓度（分组曲线尾部形状） |
| `top5day_share` / `excess_t_ex_top5` | top10% 毛超额中最好 5 天的占比 / 剔除后 t（占比高 + t 崩塌 = 尾部脆弱） |
| `signal_half_life` | 秩自相关首次跌破 0.5 的 lag（信号多慢；慢信号日频调仓白送成本） |
| `benchmark_label` | 超额对标的基准名 |

**明细表（都是 `pl.DataFrame`）**

| 字段 | 内容 |
|---|---|
| `group_returns` | 20 组 mean_ret（按因子值升序） |
| `group_returns_by_horizon` | 同一分组在各持有期的阶梯（base/2/5/10/20，报告里除以 h 画日均当量） |
| `group_returns_by_date` | date / group / ret，画分组累计收益扇 |
| `ic_by_date` / `ic_by_month` / `ic_by_weekday` | IC 时间序列与月度、周内结构 |
| `long_short_by_date` | 逐日 top / bottom / ls |
| `top_buckets` | 头部 top 1/2/5/10/20% 分层：对等权毛超额、t、**费后净超额及 t（主判据）**、对 benchmark 超额、胜率、换手、Sharpe、回撤 |
| `top_excess_by_date` | 各头部桶逐日超额 |
| `decay` | 各持有期 IC / t / t_nw（Newey-West） |
| `ic_marginal` | 边际窗口 IC（d1 / d2 / d3-5 …）：d1 独高 = 快兑现/bounce；后窗走强 = 慢兑现；平坦 ≈ 只是降噪 |
| `signal_ac` | 因子秩自相关曲线（lag 1/2/3/5/10/20） |
| `holding_survival` | 持有期费后存活表：top10% 毛/费后日均、换手摊销成本、NW t——回答"哪个持有期下费后存活" |
| `ic_by_sector` / `ic_by_size` | 行业 / 市值五分位 IC 分解（传了对应输入才有） |

成本口径：多头调仓双边成本 0.0015（佣金+印花税+滑点一篮子），年化 Sharpe 按 244 交易日。
这两个是写死的常数——想换口径，改 `factor_eval/src/factor_eval/evaluate.py`。

### 3.3 report_pdf：评价报告 PDF

```python
from factor_eval import report_pdf

report_pdf(rep, "output/my_factor.pdf", name="my_factor")
```

产出期刊风格多页 PDF：① 总览（分组 / IC / 多空）② 多头视角 top 分层
③ IC decay 与行业/市值/月度分解 ④ 交易口径对账（持有期费后存活 + 周内结构）
⑤ 分组累计收益扇 ⑥ 逐年 20 组阶梯（过拟合/衰减诊断，>4 年自动翻页）。

纯 matplotlib 绘制，不需要 quantstats。中文渲染见第 4 节。

### 3.4 其余报告函数

**这三个函数只画图，不做计算——输入得由你自己的回测器/归因器产出。**
本包不含回测引擎（和 alphalens 一样）。

- **`backtest_report_pdf(res, path, *, name, expo=None, industry=None)`**
  回测结果 dict → 2~3 页 PDF。`res` 需含键：`by_day`（date/net/gross/bench/ex_net/
  turn_oneway/n_hold）、`n_days`、`n_hold`、`gross_ann`、`net_ann`、`net_sharpe`、
  `bench_ann`、`ex_net_ann`、`ex_net_IR`、`turnover_oneway`、`maxdd`、
  `yearly`（y/net_ann/ex_net_ann），可选 `cost_note`。
  `expo` = 特征暴露表，`industry` = (sector, share) 两列。
- **`quantstats_html(res, path, *, name, benchmark=None)`**
  回测结果 → quantstats 全量 HTML（主图已替换为"策略/基准/超额"三线图）。
  `benchmark` 传 (date, ret) 两列 DataFrame 则对标该指数。
  **这是唯一需要 quantstats 的函数**，装法见 README 第 1 节。
- **`style_mirror_pdf(att, orth, path, *, name)`**
  风格归因 + 正交化结果 → 两页 PDF（风格是否解释了超额、残差信号是否还可交易）。

### 3.5 端到端示例

比第 0 节多了两样：多周期标签、以及把中间列落盘复用。

```python
import polars as pl
import factor_ops as ops
from factor_eval import evaluate, report_pdf

daily = pl.read_parquet("your_daily_bars.parquet").sort("code", "date")

# 1. 造因子：先落中间列，再做截面（ts_ 与 cs_ 不能直接套，见 2.0）
factor = (
    daily.with_columns(pl.col("close").pct_change().over("code").alias("_r1"))
         .with_columns(ops.ts_mean("_r1", 5).alias("_mom5"))
         .with_columns(ops.cs_rank("_mom5").alias("factor_value"))
         .select("date", "code", "factor_value")
         .drop_nulls()
)

# 2. 标签：主口径 fwd_ret（T+1），另带 5/10 日进 IC decay
labels = (
    daily.with_columns(
        (pl.col("close").shift(-1) / pl.col("close") - 1).over("code").alias("fwd_ret"),
        (pl.col("close").shift(-5) / pl.col("close") - 1).over("code").alias("fwd_ret_5"),
        (pl.col("close").shift(-10) / pl.col("close") - 1).over("code").alias("fwd_ret_10"),
    )
    .select("date", "code", "fwd_ret", "fwd_ret_5", "fwd_ret_10")
    .drop_nulls("fwd_ret")
)

# 3. 评价 + 报告
rep = evaluate(factor, labels, n_groups=20)
print(rep)
report_pdf(rep, "mom5.pdf", name="mom5")

# 4. 想看 T+5 主口径：换名 + 声明持有期
labels5 = (labels.select("date", "code", "fwd_ret_5")
                 .rename({"fwd_ret_5": "fwd_ret"}).drop_nulls())
rep5 = evaluate(factor, labels5, n_groups=20, overlap_h=5)
print(rep5)
```

中间结果反复用就落盘：`factor.write_parquet("f_mom5.parquet")`，下次直接读，别每次重算。

---

## 4. 排错

**按出现频率排序：**

1. **`ContractError: 缺少必需列`** → 对照第 1 节检查列名。
2. **`ts_*` 结果全是错值**（不报错，但数值明显不对）→ 忘了按 `(code, date)` 排序。
3. **滚动结果全是 null** → 窗口期内样本不足（默认严格口径），显式传 `min_samples`。
4. **因子整列是 null** → 跨分组嵌套，见 2.0 节。这是最常见的坑。
5. **bar 级函数报排序相关错误** → bar 表没按 `(code, dt)` 排序，或缺 `date` 列。
6. **`evaluate` 报重复键** → `(date, code)` 不唯一，先去重。
7. **`evaluate` 报 benchmark 缺样本日** → benchmark 必须覆盖因子表的每一个交易日。

**环境相关：**

| 现象 | 原因 / 处理 |
|---|---|
| `ts_*` 报 `min_periods` 相关错误 | polars < 1.21。该参数在 1.21 改名为 `min_samples`，旧名已删，升级即可 |
| `import factor_ops` 报 `TypeError: unsupported operand type(s) for \|` | Python < 3.10，升级 |
| `[report] 未找到 CJK 字体，中文将渲染为方块` | 只影响报告里的中文。中文只可能出现在"分行业 IC"图的行业名上——行业名是英文/代码就可忽略。要中文则装任意 CJK 字体（自动扫 `~/.fonts` 和 `/usr/share/fonts` 里名字含 `cjk`/`noto`/`wqy`/`hei` 的），或 `export LUX_CJK_FONT=/path/to/font.ttf` |
| `findfont: Failed to find font weight semibold` | matplotlib 噪音，无害 |

**看不懂某个函数在干什么**：源码就在 `factor_ops/src/` 和 `factor_eval/src/` 下，
每个函数都有 docstring，`EvalReport` 的每个字段都有行内注释。
