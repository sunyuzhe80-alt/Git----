"""因子评价器：evaluate(factor, fwd_ret) -> EvalReport。

一个函数一张报告，不是回测系统。输入两张标准表：

  factor : date / code / factor_value（factor_output 的输出即可）
  fwd_ret: date / code / fwd_ret（远期收益；口径由调用方决定，
           对齐与无前视由调用方负责——评价器只做统计，不替你想）
           可附加多周期列 fwd_ret_<h>（如 fwd_ret_5 / fwd_ret_10），
           自动产出 IC decay（主统计仍只看 fwd_ret）。

可选输入：
  benchmark: date / bench_ret   多头超额与 alpha/beta 的基准（如中证 500/
             1000 的同口径远期收益）。不传则退化为全市场等权——这只是
             没有基准时的兜底，正式结论应传真基准。样本日缺基准直接报错，
             不静默丢日。
  sectors: date / code / sector       行业内日度 IC（组内 ≥5 只才计）
  mkt_cap: date / code / mkt_cap      日内市值五分位（Q1 小 … Q5 大）IC

统一尺子：所有因子过同一套指标，分组固定 ≥20 组（默认 20），"好/坏"
的结论才可比。指标集合或算法变动 = 换尺子，golden test 会红，必须
显式重落盘。PDF 报告在 EvalReport 之上生成（规划中），统计口径只此一份。
"""

import math
from dataclasses import dataclass

import polars as pl

from factor_eval._contracts import ContractError, require_columns

# 多头精细分层（A 股只能做多，重点看头部）；尺子的一部分，不做参数
TOP_FRACTIONS = (0.01, 0.02, 0.05, 0.10, 0.20)
# 多头调仓双边成本（佣金+印花税+滑点的一篮子估计 ≈15bp）；尺子常量
COST_ROUND_TRIP = 0.0015
# A 股年交易日，年化 Sharpe 用
TRADING_DAYS = 244


@dataclass
class EvalReport:
    n_obs: int                  # 参与统计的 (date, code) 样本数
    n_dates: int                # 可计算 IC 的日期数
    coverage: float             # factor 行成功配上 fwd_ret 的比例
    ic_mean: float              # 日度 spearman IC 均值
    ic_std: float
    icir: float
    ic_tstat: float             # ICIR * sqrt(n_dates)
    ic_pvalue: float            # 双侧（正态近似）
    ic_skew: float
    ic_kurtosis: float          # fisher（正态=0）
    ic_pos_rate: float          # IC > 0 的日期占比
    monotonicity: float         # 分组序号 vs 组均收益的 spearman
    long_short_mean: float      # 顶组 - 底组 日均收益
    long_short_tstat: float
    ls_alpha: float             # L/S 对全市场等权的日度 OLS alpha
    ls_beta: float
    ls_sharpe: float            # L/S 年化 Sharpe（×sqrt(TRADING_DAYS)）
    ls_max_drawdown: float      # L/S 累计（算术加和）最大回撤幅度（正数）
    rank_autocorr: float        # 相邻日因子秩自相关（换手的反面）
    group_returns: pl.DataFrame      # group / mean_ret（按因子值升序分组）
    group_returns_by_horizon: pl.DataFrame  # horizon / group / mean_ret：同一分组在各持有期
                                     #   的阶梯（base/2/3/5/10/20;报告除以 h 画日均当量）
    group_returns_by_date: pl.DataFrame  # date / group / ret（每组逐日均值，画累计收益扇）
    ic_by_date: pl.DataFrame         # date / ic
    long_short_by_date: pl.DataFrame # date / top / bottom / ls
    top_buckets: pl.DataFrame        # 头部分层汇总：bucket / fraction / avg_n /
                                     #   excess_mean / excess_tstat（对评测票池等权=纯选股，主判据）/
                                     #   bench_excess_mean / bench_excess_tstat（对 benchmark，含 beta）/
                                     #   hit_rate / turnover / net_excess_mean / net_excess_tstat
                                     #   （净=等权超额扣换手×成本）/ sharpe / max_drawdown
    top_excess_by_date: pl.DataFrame # date / bucket / excess（对评测票池等权的超额）
    decay: pl.DataFrame              # horizon / ic_mean / ic_std / icir / ic_tstat /
                                     #   ic_tstat_nw（Newey-West，滞后 = 周期-1，
                                     #   校正重叠采样的自相关虚高）
    ic_marginal: pl.DataFrame        # window / ic_mean / ic_tstat_nw：边际窗口 IC
                                     #   （相邻周期差分收益，d1 / d2 / d3 / d4-d5 / …）。
                                     #   判别:d1 独高=bounce/快兑现；后窗走强=慢兑现；
                                     #   各窗平坦≈只是降噪(周频好看是 sqrt(h) 平均)
    signal_ac: pl.DataFrame          # lag / ac：因子秩自相关曲线（lag∈{1,2,3,5,10,20}）
    signal_half_life: float          # 秩自相关首次跌破 0.5 的 lag（线性内插；不破→inf）
    holding_survival: pl.DataFrame   # 持有期费后存活表：horizon / h / gross_dly /
                                     #   turnover / cost_dly / net_dly / net_tstat_nw
                                     #   （top10% 对全市场等权，成本按持有期摊销——
                                     #   回答"哪个持有期下费后存活"）
    ic_by_weekday: pl.DataFrame      # wd(1=周一) / ic_mean / t / n_days
                                     #   （周内结构：情形 B/C 判别，见 AGENTS.md）
    ic_by_month: pl.DataFrame        # year / month / ic_mean / n_days
    ic_by_sector: pl.DataFrame       # sector / n_dates / avg_n / ic_mean / icir
    ic_by_size: pl.DataFrame         # size_q / n_dates / avg_n / ic_mean / icir
    benchmark_label: str             # 超额/alpha/beta 对标的基准
    # ---- 厚尾大前提的两个标配诊断（skill §0b）----
    tail_gradient_top: float         # G19 − mean(G10..G18)：顶尾信息浓度
    tail_gradient_bottom: float      # G0 − mean(G1..G9)：底尾（负值=底尾更差，正常）
    top5day_share: float             # top10% 累计毛超额中最好 5 天的占比
    excess_t_ex_top5: float          # 剔除最好 5 天后 top10% 毛超额 t（崩塌=尾部脆弱）
    direction: float                 # +1 多头=高因子值；-1 多头=低因子值（=sign(IC)）
    non_monotone: bool               # IC(主体)与端点(尾部)符号矛盾 → 定向存疑

    def __str__(self) -> str:
        groups = "  ".join(
            f"G{int(r['group'])}:{r['mean_ret']:+.4f}"
            for r in self.group_returns.iter_rows(named=True)
        )
        tops = "  |  ".join(
            f"{r['bucket']}: exc(eqw) {r['excess_mean']:+.4f} t {r['excess_tstat']:+.1f} "
            f"net {r['net_excess_mean']:+.4f} | bench t {r['bench_excess_tstat']:+.1f} "
            f"hit {r['hit_rate']:.0%} tov {r['turnover']:.0%}"
            for r in self.top_buckets.iter_rows(named=True)
            if r["bucket"] in ("top 5%", "top 10%")
        )
        return (
            f"EvalReport  obs={self.n_obs}  dates={self.n_dates}  "
            f"coverage={self.coverage:.1%}  "
            f"long={'high' if self.direction > 0 else 'low'}-factor"
            f"{'  [NON-MONOTONE: IC/端点矛盾]' if self.non_monotone else ''}\n"
            f"IC     mean={self.ic_mean:+.4f}  std={self.ic_std:.4f}  "
            f"ICIR={self.icir:+.2f}  t={self.ic_tstat:+.2f}  "
            f"p={self.ic_pvalue:.2g}  skew={self.ic_skew:+.2f}  "
            f"kurt={self.ic_kurtosis:+.2f}  pos={self.ic_pos_rate:.0%}\n"
            f"Groups {groups}  mono={self.monotonicity:+.2f}\n"
            f"L/S    mean={self.long_short_mean:+.4f}  "
            f"t={self.long_short_tstat:+.2f}  "
            f"alpha={self.ls_alpha:+.5f}  beta={self.ls_beta:+.2f}  "
            f"sharpe={self.ls_sharpe:+.2f}  mdd={self.ls_max_drawdown:.3f}  "
            f"rank_autocorr={self.rank_autocorr:+.2f}\n"
            f"Long   {tops}\n"
            f"Tails  grad_top={self.tail_gradient_top:+.5f}  "
            f"grad_bot={self.tail_gradient_bottom:+.5f}  "
            f"top5day_share={self.top5day_share:.0%}  "
            f"t_ex_top5={self.excess_t_ex_top5:+.1f}\n"
            f"Decay  " + "  ".join(
                f"{r['horizon']}: IC {r['ic_mean']:+.3f} (t_nw {r['ic_tstat_nw']:+.1f})"
                for r in self.decay.iter_rows(named=True)
            )
        )


def evaluate(
    factor: pl.DataFrame,
    fwd_ret: pl.DataFrame,
    *,
    n_groups: int = 20,
    benchmark: pl.DataFrame | None = None,
    sectors: pl.DataFrame | None = None,
    mkt_cap: pl.DataFrame | None = None,
    overlap_h: int = 1,
) -> EvalReport:
    """overlap_h: 主标签的持有天数(重叠口径)。默认 1 = T+1 非重叠,行为与历史完全一致。
    调用方把 fwd_ret_5 换名为 fwd_ret 传入且 overlap_h=5 时,主口径全部 t/p 走
    Newey-West(lag=h−1)——重叠标签把每个观测"复印" h 份,裸 t 虚高 ~√h;
    点估计(分组阶梯/IC均值/mono)无偏,不受影响。ICIR/IC>0 胜率降级为描述性,
    只可与同 overlap_h 口径比较。"""
    if n_groups < 20:
        raise ContractError(
            f"evaluate: n_groups={n_groups} < 20。分组数是统一尺子的一部分，"
            "固定 ≥20 组；改尺子请改这里并重落盘全部 golden。"
        )
    require_columns(factor.columns, ["date", "code", "factor_value"], "evaluate(factor)")
    require_columns(fwd_ret.columns, ["date", "code", "fwd_ret"], "evaluate(fwd_ret)")
    if factor.height == 0:
        raise ContractError("evaluate: factor 为空")
    for label, frame in (("factor", factor), ("fwd_ret", fwd_ret)):
        n_key = frame.select(pl.struct("date", "code").n_unique()).item()
        if n_key != frame.height:
            raise ContractError(
                f"evaluate: {label} 存在重复 (date, code) 键（{frame.height - n_key} 处）"
            )

    # 多周期：fwd_ret 为主口径，fwd_ret_<h> 仅进 decay
    extra_horizons = [c for c in fwd_ret.columns if c.startswith("fwd_ret_")]
    try:
        extra_horizons.sort(key=lambda c: int(c.removeprefix("fwd_ret_")))
    except ValueError as e:
        raise ContractError(
            f"evaluate: 多周期列名须为 fwd_ret_<整数>，实际 {extra_horizons}"
        ) from e
    horizon_cols = ["fwd_ret", *extra_horizons]
    df = factor.join(
        fwd_ret.select("date", "code", *horizon_cols), on=["date", "code"], how="inner"
    )
    coverage = df.height / factor.height
    df = df.drop_nulls(["factor_value", "fwd_ret"]).sort("date", "code")
    if df.height == 0:
        raise ContractError("evaluate: factor 与 fwd_ret 配对后无有效样本")

    # ---- 日度 spearman IC（日内常数因子的日期 corr 为 null/NaN，丢弃）
    ic_by_date = _daily_spearman(df, "fwd_ret")
    n_dates = ic_by_date.height
    if n_dates == 0:
        raise ContractError(
            "evaluate: 没有任何日期能计算 IC（因子或收益在每个日内都是常数？）"
        )
    ic = ic_by_date["ic"]
    ic_mean = float(ic.mean())
    ic_std = _f(ic.std())
    icir = ic_mean / ic_std if ic_std and not math.isnan(ic_std) else float("nan")
    ic_tstat = icir * math.sqrt(n_dates) if not math.isnan(icir) else float("nan")
    ic_pos_rate = float((ic > 0).mean())
    if overlap_h > 1:  # 重叠主标签:裸 t 虚高 ~√h → NW(lag=h−1);ic_mean/胜率等点估计不动
        ic_tstat = _nw_tstat(ic.to_list(), overlap_h - 1)
    ic_pvalue = (
        math.erfc(abs(ic_tstat) / math.sqrt(2)) if not math.isnan(ic_tstat) else float("nan")
    )
    ic_skew = _f(ic.skew())
    ic_kurtosis = _f(ic.kurtosis())

    # ---- 方向定向（修 long-only 评价 bug）。
    # direction = sign(端点谱 G_top − G_bottom)：top-k 实际赚的是两端原始收益差(幅度)，
    # 故方向跟随【可交易端点谱】，而非 sign(IC)（秩/等权日口径，与端点谱可异号——
    # 异号即 non_monotone）。分组曲线 group/group_returns/mono 用原始升序分组
    # （展示真实形状，与方向无关）；策略口径 LS/top-bucket/survival/tail 用定向 _drank/_dgroup。
    df = df.with_columns(
        pl.col("factor_value").rank("ordinal").over("date").cast(pl.Int64).alias("_rank"),
        pl.len().over("date").cast(pl.Int64).alias("_cnt"),
    ).with_columns(
        ((pl.col("_rank") - 1) * n_groups // pl.col("_cnt")).cast(pl.Int32).alias("group"),
    )
    daily_groups = df.group_by("date", "group").agg(pl.col("fwd_ret").mean().alias("ret"))
    group_returns = (
        daily_groups.group_by("group")
        .agg(pl.col("ret").mean().alias("mean_ret"))
        .sort("group")
    )
    # 各持有期的同一 20 组阶梯(分组不变,只换收益周期;报告侧除以 h 得日均当量,
    # 与 T+1 柱同轴可比——形状不变=排序稳,长端更陡=慢兑现,变平=alpha 衰减)
    _gh = [group_returns.with_columns(pl.lit("base").alias("horizon"))]
    for _col in extra_horizons:
        _gh.append(
            df.filter(pl.col(_col).is_not_null())
            .group_by("date", "group").agg(pl.col(_col).mean().alias("ret"))
            .group_by("group").agg(pl.col("ret").mean().alias("mean_ret"))
            .sort("group")
            .with_columns(pl.lit(_col.removeprefix("fwd_ret_")).alias("horizon"))
        )
    group_returns_by_horizon = pl.concat(_gh).select("horizon", "group", "mean_ret")
    monotonicity = _f(
        group_returns.select(pl.corr("group", "mean_ret", method="spearman")).item()
    )
    # 端点谱（因子最高组 − 最低组的原始收益差）= top-k 可交易的方向锚
    raw_tb = _f(
        group_returns["mean_ret"].tail(1).item() - group_returns["mean_ret"].head(1).item()
    )
    direction = 1.0 if raw_tb >= 0 else -1.0
    # 非单调：IC（主体/秩）与端点谱（尾部/幅度）符号矛盾 = body 与 tails 打架
    non_monotone = bool(ic_mean * raw_tb < 0)

    # 定向分组（策略口径用）：_dgroup 顶 = 多头侧（按端点谱方向）
    df = df.with_columns(
        (pl.col("factor_value") * direction).rank("ordinal").over("date").cast(pl.Int64).alias("_drank"),
    ).with_columns(
        ((pl.col("_drank") - 1) * n_groups // pl.col("_cnt")).cast(pl.Int32).alias("_dgroup"),
    )
    daily_dgroups = df.group_by("date", "_dgroup").agg(pl.col("fwd_ret").mean().alias("ret"))
    dgroup_returns = (
        daily_dgroups.group_by("_dgroup")
        .agg(pl.col("ret").mean().alias("mean_ret"))
        .sort("_dgroup")
    )

    # ---- 多空：top/bottom 展示原始两端（G_max=因子最高组, G_min=因子最低组，
    #      不定向，看真实表现），long-short 按 direction 定向（ls=dir×(top−bottom)）
    top_g = daily_groups["group"].max()
    bot_g = daily_groups["group"].min()
    ls = (
        daily_groups.filter(pl.col("group") == top_g)
        .select("date", pl.col("ret").alias("top"))
        .join(
            daily_groups.filter(pl.col("group") == bot_g).select(
                "date", pl.col("ret").alias("bottom")
            ),
            on="date",
        )
        .with_columns((direction * (pl.col("top") - pl.col("bottom"))).alias("ls"))
    )
    ls_mean = _f(ls["ls"].mean())
    ls_std = _f(ls["ls"].std())
    ls_tstat = (
        ls_mean / ls_std * math.sqrt(ls.height)
        if ls.height > 1 and ls_std and not math.isnan(ls_std)
        else float("nan")
    )
    if overlap_h > 1 and ls.height > 1:
        # NW 依赖时间顺序;ls 出自无序 group_by,必须先按日期排序
        ls_tstat = _nw_tstat(ls.sort("date")["ls"].to_list(), overlap_h - 1)
    ls_sharpe = (
        ls_mean / ls_std * math.sqrt(TRADING_DAYS)
        if ls_std and not math.isnan(ls_std)
        else float("nan")
    )
    ls_max_drawdown = _max_drawdown(ls.sort("date")["ls"])

    # ---- 相邻交易日映射（秩自相关与头部换手共用）
    dates = df["date"].unique().sort()
    date_pairs = pl.DataFrame({"date": dates, "prev_date": dates.shift(1)}).drop_nulls()

    # ---- 基准：多头超额与 L/S alpha/beta 都对它算
    if benchmark is not None:
        require_columns(benchmark.columns, ["date", "bench_ret"], "evaluate(benchmark)")
        mkt = benchmark.select("date", pl.col("bench_ret").alias("mkt"))
        if mkt["date"].n_unique() != mkt.height:
            raise ContractError("evaluate: benchmark 存在重复 date")
        missing = df.select("date").unique().join(mkt, on="date", how="anti")
        if missing.height:
            raise ContractError(
                f"evaluate: benchmark 缺 {missing.height} 个样本日"
                f"（如 {missing['date'].min()}）——宁可报错也不静默丢日"
            )
        benchmark_label = "user benchmark"
    else:
        mkt = df.group_by("date").agg(pl.col("fwd_ret").mean().alias("mkt"))
        benchmark_label = "equal-weight universe (fallback)"
    ls_mkt = ls.join(mkt, on="date")
    ls_alpha = ls_beta = float("nan")
    if ls_mkt.height > 1:
        cov_, var_, l_mean, m_mean = ls_mkt.select(
            pl.cov("ls", "mkt").alias("c"),
            pl.col("mkt").var().alias("v"),
            pl.col("ls").mean().alias("lm"),
            pl.col("mkt").mean().alias("mm"),
        ).row(0)
        if var_:
            ls_beta = _f(cov_) / var_
            ls_alpha = l_mean - ls_beta * m_mean

    # ---- 多头精细分层：top 1/2/5/10/20%（A 股多头视角）
    #   excess       = 对评测票池等权（纯选股，与 holding_survival 同口径，主判据）；
    #   bench_excess = 对传入 benchmark（如 CSI500，含 beta/风格暴露）；
    #   两者之差 = 风格/beta 偏移，使 intensity 类"对500像alpha、对等权≈0"陷阱自动现形。
    uni_mkt = df.group_by("date").agg(pl.col("fwd_ret").mean().alias("uni"))
    bucket_rows, excess_frames = [], []
    for frac in TOP_FRACTIONS:
        n_top = pl.max_horizontal(
            (pl.col("_cnt") * frac).floor().cast(pl.Int64), pl.lit(1, dtype=pl.Int64)
        )
        sub = df.filter(pl.col("_drank") > pl.col("_cnt") - n_top)
        by_date = (
            sub.group_by("date")
            .agg(pl.col("fwd_ret").mean().alias("top_ret"), pl.len().cast(pl.Int64).alias("n"))
            .join(uni_mkt, on="date")
            .join(mkt, on="date")
            .with_columns(
                (pl.col("top_ret") - pl.col("uni")).alias("excess"),
                (pl.col("top_ret") - pl.col("mkt")).alias("bench_excess"),
            )
            .sort("date")
        )
        exc = by_date["excess"]
        e_mean, e_std = _f(exc.mean()), _f(exc.std())
        e_tstat = (
            e_mean / e_std * math.sqrt(by_date.height)
            if by_date.height > 1 and e_std and not math.isnan(e_std)
            else float("nan")
        )
        bexc = by_date["bench_excess"]
        be_mean, be_std = _f(bexc.mean()), _f(bexc.std())
        be_tstat = (
            be_mean / be_std * math.sqrt(by_date.height)
            if by_date.height > 1 and be_std and not math.isnan(be_std)
            else float("nan")
        )
        if overlap_h > 1 and by_date.height > 1:
            e_tstat = _nw_tstat(exc.to_list(), overlap_h - 1)
            be_tstat = _nw_tstat(bexc.to_list(), overlap_h - 1)
        hit_rate = float((exc > 0).mean())
        # 头部成员日度换手：1 - |S_t ∩ S_{t-1}| / n_t
        if date_pairs.height:
            kept = (
                sub.select("date", "code")
                .join(date_pairs, on="date")
                .join(
                    sub.select(pl.col("date").alias("prev_date"), "code"),
                    on=["prev_date", "code"],
                )
                .group_by("date")
                .agg(pl.len().cast(pl.Int64).alias("kept"))
            )
            tov = (
                by_date.join(date_pairs.select("date"), on="date")
                .join(kept, on="date", how="left")
                .with_columns((1 - pl.col("kept").fill_null(0) / pl.col("n")).alias("tov"))
                .sort("date")  # join 可能破坏顺序;net 序列喂 NW 须按时间排
            )
            turnover = _f(tov["tov"].mean()) if tov.height else float("nan")
            # 费后净超额：日度 净 = 毛超额 - 当日换手 × 双边成本（首日无前日，不计）
            net = tov.with_columns(
                (pl.col("excess") - pl.col("tov") * COST_ROUND_TRIP).alias("net")
            )["net"]
            net_mean, net_std = _f(net.mean()), _f(net.std())
            net_tstat = (
                net_mean / net_std * math.sqrt(net.len())
                if net.len() > 1 and net_std and not math.isnan(net_std)
                else float("nan")
            )
            if overlap_h > 1 and net.len() > 1:
                net_tstat = _nw_tstat(net.to_list(), overlap_h - 1)
        else:
            turnover = net_mean = net_tstat = float("nan")
        sharpe = (
            e_mean / e_std * math.sqrt(TRADING_DAYS)
            if e_std and not math.isnan(e_std)
            else float("nan")
        )
        label = f"top {frac:.0%}"
        bucket_rows.append(
            {
                "bucket": label,
                "fraction": frac,
                "avg_n": _f(by_date["n"].mean()),
                "excess_mean": e_mean,
                "excess_tstat": e_tstat,
                "bench_excess_mean": be_mean,
                "bench_excess_tstat": be_tstat,
                "hit_rate": hit_rate,
                "turnover": turnover,
                "net_excess_mean": net_mean,
                "net_excess_tstat": net_tstat,
                "sharpe": sharpe,
                "max_drawdown": _max_drawdown(exc),
            }
        )
        excess_frames.append(by_date.select("date", pl.lit(label).alias("bucket"), "excess"))
    top_buckets = pl.DataFrame(bucket_rows)
    top_excess_by_date = pl.concat(excess_frames)

    # ---- 相邻日因子秩自相关（稳定性；低 = 高换手）
    paired = (
        df.select("date", "code", "factor_value")
        .join(date_pairs, on="date")
        .join(
            df.select(
                pl.col("date").alias("prev_date"), "code",
                pl.col("factor_value").alias("prev_value"),
            ),
            on=["prev_date", "code"],
        )
    )
    if paired.height:
        rac = (
            paired.group_by("date")
            .agg(pl.corr("factor_value", "prev_value", method="spearman").alias("ac"))
            .filter(pl.col("ac").is_finite())["ac"]
        )
        rank_autocorr = _f(rac.mean()) if rac.len() else float("nan")
    else:
        rank_autocorr = float("nan")

    # ---- IC decay：每个远期周期一行。
    # h 日收益按日采样是重叠的，IC 序列自相关使普通 t 虚高；
    # ic_tstat_nw 用 Newey-West（滞后 = h-1）校正。base 视为不重叠（滞后 0）。
    decay_rows = []
    for col in horizon_cols:
        d_ic = _daily_spearman(df.filter(pl.col(col).is_not_null()), col)["ic"]
        d_mean, d_std = _f(d_ic.mean()), _f(d_ic.std())
        d_icir = d_mean / d_std if d_std and not math.isnan(d_std) else float("nan")
        lag = (overlap_h - 1) if col == "fwd_ret" else int(col.removeprefix("fwd_ret_")) - 1
        decay_rows.append(
            {
                "horizon": "base" if col == "fwd_ret" else col.removeprefix("fwd_ret_"),
                "ic_mean": d_mean,
                "ic_std": d_std,
                "icir": d_icir,
                "ic_tstat": d_icir * math.sqrt(d_ic.len())
                if d_ic.len() and not math.isnan(d_icir)
                else float("nan"),
                "ic_tstat_nw": _nw_tstat(d_ic.to_list(), lag),
            }
        )
    decay = pl.DataFrame(decay_rows)

    # ---- 边际窗口 IC（兑现节奏判别:相邻周期差分收益 (1+fwd_k)/(1+fwd_prev) − 1）
    # d1 = base 本身;后续窗口重叠采样 → NW 滞后 = 窗长−1。
    marg_rows = [
        {"window": "d1", "ic_mean": decay_rows[0]["ic_mean"],
         "ic_tstat_nw": decay_rows[0]["ic_tstat_nw"]}
    ]
    _hs = [("fwd_ret", 1)] + [(c, int(c.removeprefix("fwd_ret_"))) for c in extra_horizons]
    for (c0, h0), (c1, h1) in zip(_hs, _hs[1:]):
        sub = df.filter(
            pl.col(c0).is_not_null() & pl.col(c1).is_not_null()
        ).with_columns(((1.0 + pl.col(c1)) / (1.0 + pl.col(c0)) - 1.0).alias("_marg"))
        m_ic = _daily_spearman(sub, "_marg")["ic"]
        if not m_ic.len():
            continue
        m_mean, m_std = _f(m_ic.mean()), _f(m_ic.std())
        marg_rows.append(
            {
                "window": f"d{h0 + 1}" if h1 - h0 == 1 else f"d{h0 + 1}-d{h1}",
                "ic_mean": m_mean,
                "ic_tstat_nw": _nw_tstat(m_ic.to_list(), max(h1 - h0 - 1, 0)),
            }
        )
    ic_marginal = pl.DataFrame(marg_rows)

    # ---- 信号自相关曲线 + 半衰期（多 lag 版 rank_autocorr:信号本身多慢）
    _ds = df.select(pl.col("date").unique().sort().alias("date")).to_series()
    sig_rows = []
    for _lag in (1, 2, 3, 5, 10, 20):
        if _ds.len() <= _lag:
            break
        dp = pl.DataFrame(
            {"date": _ds.slice(_lag), "_lag_date": _ds.slice(0, _ds.len() - _lag)}
        )
        pr = (
            df.select("date", "code", "factor_value")
            .join(dp, on="date")
            .join(
                df.select(
                    pl.col("date").alias("_lag_date"), "code",
                    pl.col("factor_value").alias("_lag_value"),
                ),
                on=["_lag_date", "code"],
            )
        )
        if not pr.height:
            continue
        ac_s = (
            pr.group_by("date")
            .agg(pl.corr("factor_value", "_lag_value", method="spearman").alias("ac"))
            .filter(pl.col("ac").is_finite())["ac"]
        )
        if ac_s.len():
            sig_rows.append({"lag": _lag, "ac": _f(ac_s.mean())})
    signal_ac = (
        pl.DataFrame(sig_rows)
        if sig_rows
        else pl.DataFrame(schema={"lag": pl.Int64, "ac": pl.Float64})
    )
    signal_half_life = float("inf")
    _pl_, _pa = 0, 1.0
    for r in sig_rows:
        if r["ac"] is not None and not math.isnan(r["ac"]) and r["ac"] < 0.5:
            signal_half_life = _pl_ + (_pa - 0.5) / max(_pa - r["ac"], 1e-12) * (r["lag"] - _pl_)
            break
        _pl_, _pa = r["lag"], r["ac"]

    # ---- 厚尾大前提诊断 ①：顶/底尾信息梯度（分组曲线的尾部形状量化）
    gr = {int(r["_dgroup"]): r["mean_ret"] for r in dgroup_returns.iter_rows(named=True)}
    _g = lambda ks: [gr[k] for k in ks if k in gr and gr[k] is not None]  # noqa: E731
    mid_hi, mid_lo = _g(range(10, 19)), _g(range(1, 10))
    tail_gradient_top = (
        gr.get(19, float("nan")) - sum(mid_hi) / len(mid_hi) if mid_hi else float("nan")
    )
    tail_gradient_bottom = (
        gr.get(0, float("nan")) - sum(mid_lo) / len(mid_lo) if mid_lo else float("nan")
    )

    # ---- 持有期费后存活表（组合层对账：成本按持有期摊销）
    # 口径：top10% 桶对全市场等权的 h 日超额折成日均当量，减去
    # "lag-h 成员换手 × 双边成本 / h"；NW t 滞后 h-1。
    dates_idx = pl.DataFrame({"date": dates}).with_row_index("_didx")
    n_top10 = pl.max_horizontal(
        (pl.col("_cnt") * 0.10).floor().cast(pl.Int64), pl.lit(1, dtype=pl.Int64)
    )
    top10 = df.filter(pl.col("_drank") > pl.col("_cnt") - n_top10).select("date", "code")
    surv_rows = []
    for col in horizon_cols:
        h = 1 if col == "fwd_ret" else int(col.removeprefix("fwd_ret_"))
        sub = df.filter(pl.col(col).is_not_null())
        um = sub.group_by("date").agg(pl.col(col).mean().alias("_um"))
        ex = (
            top10.join(sub.select("date", "code", col), on=["date", "code"])
            .group_by("date")
            .agg(pl.col(col).mean().alias("_tg"))
            .join(um, on="date")
            .with_columns(((pl.col("_tg") - pl.col("_um")) / h).alias("_ex"))
            .sort("date")
        )
        cur = top10.join(dates_idx, on="date")
        held = cur.with_columns((pl.col("_didx") + h).alias("_didx")).select("_didx", "code")
        kept = (
            cur.join(held, on=["_didx", "code"])
            .group_by("date")
            .agg(pl.len().alias("_kept"))
        )
        tov_df = (
            cur.group_by("date").agg(pl.len().alias("_nt"))
            .join(dates_idx, on="date")
            .filter(pl.col("_didx") >= h)
            .join(kept, on="date", how="left")
            .with_columns((1 - pl.col("_kept").fill_null(0) / pl.col("_nt")).alias("_tov"))
        )
        tov_h = _f(tov_df["_tov"].mean()) if tov_df.height else float("nan")
        cost_dly = tov_h * COST_ROUND_TRIP / h if not math.isnan(tov_h) else float("nan")
        gross_dly = _f(ex["_ex"].mean())
        net_series = (
            [v - cost_dly for v in ex["_ex"].to_list()] if not math.isnan(cost_dly) else []
        )
        surv_rows.append(
            {
                "horizon": "T+1" if h == 1 else f"T+1→T+{h}",
                "h": h,
                "gross_dly": gross_dly,
                "turnover": tov_h,
                "cost_dly": cost_dly,
                "net_dly": gross_dly - cost_dly,
                "net_tstat_nw": _nw_tstat(net_series, h - 1)
                if len(net_series) > 1
                else float("nan"),
            }
        )
    holding_survival = pl.DataFrame(surv_rows)

    # ---- 厚尾大前提诊断 ②：top10% 的尾部集中度（h=1 毛超额序列）
    ex1 = (
        top10.join(df.select("date", "code", "fwd_ret"), on=["date", "code"])
        .group_by("date")
        .agg(pl.col("fwd_ret").mean().alias("_tg"))
        .join(df.group_by("date").agg(pl.col("fwd_ret").mean().alias("_um")), on="date")
        .with_columns((pl.col("_tg") - pl.col("_um")).alias("_ex"))
        .sort("_ex", descending=True)["_ex"]
    )
    if ex1.len() > 6:
        total_pos = ex1.filter(ex1 > 0).sum()
        top5day_share = _f(ex1.head(5).sum() / total_pos) if total_pos else float("nan")
        rest = ex1.slice(5)
        r_mean, r_std = _f(rest.mean()), _f(rest.std())
        excess_t_ex_top5 = (
            r_mean / r_std * math.sqrt(rest.len())
            if r_std and not math.isnan(r_std)
            else float("nan")
        )
    else:
        top5day_share = excess_t_ex_top5 = float("nan")

    # ---- 周内 IC 结构（情形 B/C 判别）
    ic_by_weekday = (
        ic_by_date.with_columns(pl.col("date").dt.weekday().alias("wd"))
        .group_by("wd")
        .agg(
            pl.col("ic").mean().alias("ic_mean"),
            (pl.col("ic").mean() / pl.col("ic").std() * pl.len().cast(pl.Float64).sqrt()).alias("t"),
            pl.len().alias("n_days"),
        )
        .sort("wd")
    )

    # ---- 月度 IC
    ic_by_month = (
        ic_by_date.with_columns(
            pl.col("date").dt.year().alias("year"),
            pl.col("date").dt.month().alias("month"),
        )
        .group_by("year", "month")
        .agg(pl.col("ic").mean().alias("ic_mean"), pl.len().alias("n_days"))
        .sort("year", "month")
    )

    # ---- 行业 / 市值五分位 IC 分解（可选输入）
    if sectors is not None:
        require_columns(sectors.columns, ["date", "code", "sector"], "evaluate(sectors)")
        ic_by_sector = _grouped_ic(
            df.join(sectors.select("date", "code", "sector"), on=["date", "code"]),
            "sector",
        )
    else:
        ic_by_sector = _empty_grouped_ic("sector")

    if mkt_cap is not None:
        require_columns(mkt_cap.columns, ["date", "code", "mkt_cap"], "evaluate(mkt_cap)")
        sized = df.join(
            mkt_cap.select("date", "code", "mkt_cap"), on=["date", "code"]
        ).with_columns(
            (
                (pl.col("mkt_cap").rank("ordinal").over("date") - 1)
                * 5
                // pl.len().over("date")
            ).alias("_q")
        ).with_columns(
            pl.format("Q{}", pl.col("_q") + 1).alias("size_q")  # Q1 小 … Q5 大
        )
        ic_by_size = _grouped_ic(sized, "size_q")
    else:
        ic_by_size = _empty_grouped_ic("size_q")

    return EvalReport(
        n_obs=df.height,
        n_dates=n_dates,
        coverage=coverage,
        ic_mean=ic_mean,
        ic_std=ic_std,
        icir=icir,
        ic_tstat=ic_tstat,
        ic_pvalue=ic_pvalue,
        ic_skew=ic_skew,
        ic_kurtosis=ic_kurtosis,
        ic_pos_rate=ic_pos_rate,
        monotonicity=monotonicity,
        long_short_mean=ls_mean,
        long_short_tstat=ls_tstat,
        ls_alpha=ls_alpha,
        ls_beta=ls_beta,
        ls_sharpe=ls_sharpe,
        ls_max_drawdown=ls_max_drawdown,
        rank_autocorr=rank_autocorr,
        group_returns=group_returns,
        group_returns_by_horizon=group_returns_by_horizon,
        group_returns_by_date=daily_groups.sort("date", "group"),
        ic_by_date=ic_by_date,
        long_short_by_date=ls.sort("date"),
        top_buckets=top_buckets,
        top_excess_by_date=top_excess_by_date,
        decay=decay,
        ic_marginal=ic_marginal,
        signal_ac=signal_ac,
        signal_half_life=signal_half_life,
        holding_survival=holding_survival,
        ic_by_weekday=ic_by_weekday,
        ic_by_month=ic_by_month,
        ic_by_sector=ic_by_sector,
        ic_by_size=ic_by_size,
        benchmark_label=benchmark_label,
        tail_gradient_top=tail_gradient_top,
        tail_gradient_bottom=tail_gradient_bottom,
        top5day_share=top5day_share,
        excess_t_ex_top5=excess_t_ex_top5,
        direction=direction,
        non_monotone=non_monotone,
    )


def _daily_spearman(df: pl.DataFrame, ret_col: str) -> pl.DataFrame:
    return (
        df.group_by("date")
        .agg(pl.corr("factor_value", ret_col, method="spearman").alias("ic"))
        .filter(pl.col("ic").is_finite())
        .sort("date")
    )


def _grouped_ic(joined: pl.DataFrame, key: str) -> pl.DataFrame:
    """组内（行业/市值档）日度 IC 再按组聚合；日内组 <5 只不计。"""
    per_day = (
        joined.group_by("date", key)
        .agg(
            pl.corr("factor_value", "fwd_ret", method="spearman").alias("ic"),
            pl.len().alias("n"),
        )
        .filter((pl.col("n") >= 5) & pl.col("ic").is_finite())
    )
    return (
        per_day.group_by(key)
        .agg(
            pl.len().alias("n_dates"),
            pl.col("n").mean().alias("avg_n"),
            pl.col("ic").mean().alias("ic_mean"),
            (pl.col("ic").mean() / pl.col("ic").std()).alias("icir"),
        )
        .sort(key)
    )


def _empty_grouped_ic(key: str) -> pl.DataFrame:
    return pl.DataFrame(
        schema={
            key: pl.Utf8,
            "n_dates": pl.UInt32,
            "avg_n": pl.Float64,
            "ic_mean": pl.Float64,
            "icir": pl.Float64,
        }
    )


def _nw_tstat(x: list[float], lag: int) -> float:
    """均值的 Newey-West t（Bartlett 权重）。lag=0 即普通 t（方差用 1/n）。"""
    n = len(x)
    if n < 2:
        return float("nan")
    mean = sum(x) / n
    e = [v - mean for v in x]
    var = sum(v * v for v in e) / n
    lag = min(lag, n - 1)
    for k in range(1, lag + 1):
        gamma = sum(e[i] * e[i - k] for i in range(k, n)) / n
        var += 2 * (1 - k / (lag + 1)) * gamma
    if var <= 0:
        return float("nan")
    return mean / math.sqrt(var / n)


def _max_drawdown(series: pl.Series) -> float:
    """算术累计曲线的最大回撤幅度（正数；序列须已按时间排序）。"""
    if series.len() == 0:
        return float("nan")
    cum = series.cum_sum()
    return -_f((cum - cum.cum_max()).min())


def _f(x) -> float:
    return float("nan") if x is None else float(x)
