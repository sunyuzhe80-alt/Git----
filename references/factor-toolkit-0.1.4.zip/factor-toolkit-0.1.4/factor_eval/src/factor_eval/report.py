"""EvalReport -> 三页 PDF 报告（期刊风格排版）。

页 1：总览（分组、IC、多空）。页 2：多头视角（A 股只能做多）——
top 1/2/5/10/20% 头部分层。页 3：IC decay 与行业/市值/月度分解。

统计口径全部来自 evaluate()，本模块只负责排版渲染。图表标签用英文；
中文内容（行业名等）依赖 CJK 字体——模块加载时自动搜索并注册
（LUX_CJK_FONT 环境变量 > ~/.fonts > 系统字体目录），找不到则中文
渲染为方块并打印一次性提醒。

视觉规范：Paul Tol 学术配色（色盲安全）；红=正/多头、青绿=负（A 股
红涨绿跌习惯）；去顶/右边框；浅灰 y 网格；面板标题左对齐带 a/b/c/d。
"""

from pathlib import Path

import os

import matplotlib

matplotlib.use("Agg")

import matplotlib.font_manager as _fm
import matplotlib.pyplot as plt
import numpy as np
import polars as pl
from matplotlib.backends.backend_pdf import PdfPages

from factor_eval.evaluate import EvalReport


def _find_cjk_font() -> str | None:
    """注册并返回可用的 CJK 字体名（行业名等中文内容需要）。"""
    candidates = [os.environ.get("LUX_CJK_FONT", "")]
    for d in (Path.home() / ".fonts", Path("/usr/share/fonts")):
        if d.is_dir():
            candidates += [str(p) for p in d.rglob("*")
                           if p.suffix.lower() in (".otf", ".ttf", ".ttc")
                           and any(k in p.name.lower() for k in ("cjk", "noto", "wqy", "hei"))]
    for path in candidates:
        if path and Path(path).is_file():
            try:
                _fm.fontManager.addfont(path)
                return _fm.FontProperties(fname=path).get_name()
            except Exception:  # noqa: BLE001 字体损坏则试下一个
                continue
    print("[report] 未找到 CJK 字体，中文将渲染为方块（设 LUX_CJK_FONT 指定）")
    return None


_CJK = _find_cjk_font()

# ---- 调色板（Paul Tol high-contrast / muted）---------------------------
_UP = "#CC3311"       # 正 / 多头（红涨）
_DOWN = "#009988"     # 负 / 空头（青绿跌）
_PRIMARY = "#332288"  # 主线：累计 IC、L/S
_GREY = "#9DB2BF"     # 辅助柱（日度 IC、直方图）
_INK = "#1A1A1A"
_MUTED = "#666666"

_RC = {
    "axes.spines.top": False,
    "axes.spines.right": False,
    "axes.edgecolor": "#444444",
    "axes.linewidth": 0.8,
    "axes.grid": True,
    "axes.grid.axis": "y",
    "grid.color": "#E3E3E3",
    "grid.linewidth": 0.6,
    "axes.axisbelow": True,
    "axes.titlesize": 10,
    "axes.titleweight": "semibold",
    "axes.titlelocation": "left",
    "axes.titlepad": 8,
    "axes.labelsize": 8,
    "axes.labelcolor": _INK,
    "xtick.labelsize": 8,
    "ytick.labelsize": 8,
    "xtick.color": "#444444",
    "ytick.color": "#444444",
    "legend.frameon": False,
    "legend.fontsize": 8,
    "figure.facecolor": "white",
    "font.sans-serif": ([_CJK] if _CJK else []) + ["DejaVu Sans"],
    "axes.unicode_minus": False,  # CJK 字体缺 U+2212，用 ASCII 连字符
}


def _bucket_palette(n: int):
    return plt.cm.Blues(np.linspace(0.45, 0.92, n))


def report_pdf(rep: EvalReport, path: str | Path, *, name: str = "factor") -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with plt.rc_context(_RC):
        pages = [
            _overview_page(rep, name),
            _long_only_page(rep, name),
            _decay_decomposition_page(rep, name),
            _calibration_page(rep, name),
            _group_curve_page(rep, name),
        ]
        pages.extend(_yearly_group_pages(rep, name))  # 逐年 20 组 staircase(过拟合/衰减诊断)
        with PdfPages(path) as pdf:
            for fig in pages:
                pdf.savefig(fig)
                plt.close(fig)
    return path


def _draw_title(fig, title: str):
    """标题:CJK 宽度感知换行 + 过长缩字号,避免溢出截断。"""
    import unicodedata
    lines, cur, w = [], "", 0
    for ch in title:
        cw = 2 if unicodedata.east_asian_width(ch) in ("W", "F") else 1
        cur, w = cur + ch, w + cw
        if w >= 85 and ch in " ·":   # 视觉宽 ~85 处在分隔符断行(A4 横版一行容量,留余量)
            lines.append(cur.rstrip()); cur, w = "", 0
    if cur:
        lines.append(cur.rstrip())
    fs = 14 if len(lines) <= 1 else 11
    fig.text(0.06, 0.965, "\n".join(lines), fontsize=fs, fontweight="bold", color=_INK, va="top")


def _new_page(title: str):
    fig = plt.figure(figsize=(11.7, 8.3))  # A4 横版
    _draw_title(fig, title)
    gs = fig.add_gridspec(
        2, 2, top=0.80, bottom=0.07, left=0.06, right=0.97, hspace=0.42, wspace=0.24
    )
    return fig, gs


def _group_curve_page(rep: EvalReport, name: str):
    """末页:20 组累计收益扇——每组逐日均值的累计曲线,看分组排序随时间稳不稳、
    顶底 spread 是否持续张开(比页1的截面均值柱图信息量大得多)。低组红、高组绿。"""
    fig = plt.figure(figsize=(11.7, 8.3))
    _draw_title(fig, f"Group Cumulative Return Fan — {name}")
    n = rep.group_returns.height
    _hi = n - 1
    _long = f"high-factor (G{_hi})" if rep.direction > 0 else "low-factor (G0)"
    _nm = "   [NON-MONOTONE: IC vs tails disagree]" if rep.non_monotone else ""
    fig.text(
        0.06, 0.918,
        f"{n} groups (0 = low factor … {_hi} = high) · each line = cumulative daily group-mean forward return",
        fontsize=9, color=_MUTED,
    )
    fig.text(
        0.06, 0.892,
        f"long leg = {_long}    monotonicity = {rep.monotonicity:+.2f}{_nm}",
        fontsize=9, color=_MUTED,
    )
    ax = fig.add_axes([0.07, 0.09, 0.85, 0.73])
    cmap = plt.cm.RdYlGn
    parts = rep.group_returns_by_date.sort("group", "date").partition_by(
        "group", maintain_order=True
    )
    for sub in parts:
        g = int(sub["group"][0])
        y = np.cumsum(sub["ret"].to_numpy())
        ax.plot(
            sub["date"].to_list(), y,
            color=cmap(g / _hi if _hi else 0.5),
            lw=2.4 if g in (0, _hi) else 1.0,
            alpha=0.95 if g in (0, _hi) else 0.8,
        )
    ax.axhline(0, lw=0.9, color=_INK)
    _date_axis(ax)
    ax.set_title(
        f"Cumulative return by factor group (fan: G0 low = red … G{_hi} high = green)",
        fontsize=12, color=_INK,
    )
    ax.set_xlabel("date", fontsize=11)
    ax.set_ylabel("cumulative forward return", fontsize=11)
    ax.grid(True, alpha=0.3)
    sm = plt.cm.ScalarMappable(cmap=cmap, norm=plt.Normalize(0, _hi))
    sm.set_array([])
    cbar = fig.colorbar(sm, ax=ax, fraction=0.025, pad=0.01)
    cbar.set_label("factor group (low → high)", fontsize=9)
    return fig


def _sign_colors(vals):
    return [(_UP if v >= 0 else _DOWN) for v in vals]


def _date_axis(ax):
    ax.tick_params(axis="x", rotation=30)


def _overview_page(rep: EvalReport, name: str):
    fig, gs = _new_page(f"Factor Evaluation — {name}")
    dates = rep.ic_by_date["date"].to_list()
    _long = "high-factor" if rep.direction > 0 else "low-factor"
    _nm = "   [NON-MONOTONE: IC vs tails disagree]" if rep.non_monotone else ""
    fig.text(
        0.06, 0.915,
        f"{dates[0]} … {dates[-1]}    obs={rep.n_obs:,}   dates={rep.n_dates}   "
        f"coverage={rep.coverage:.1%}   groups={rep.group_returns.height}   "
        f"long leg = {_long} (dir={rep.direction:+.0f}, sign IC){_nm}",
        fontsize=9, color=_MUTED,
    )
    fig.text(
        0.06, 0.882,
        f"IC mean {rep.ic_mean:+.4f}   std {rep.ic_std:.4f}   ICIR {rep.icir:+.2f}   "
        f"t {rep.ic_tstat:+.2f}   p {rep.ic_pvalue:.2g}   skew {rep.ic_skew:+.2f}   "
        f"kurt {rep.ic_kurtosis:+.2f}   IC>0 {rep.ic_pos_rate:.0%}",
        fontsize=10, family="monospace", color=_INK,
    )
    fig.text(
        0.06, 0.852,
        f"L/S mean {rep.long_short_mean:+.4f}   t {rep.long_short_tstat:+.2f}   "
        f"alpha {rep.ls_alpha:+.5f}   beta {rep.ls_beta:+.2f}   "
        f"Sharpe {rep.ls_sharpe:+.2f}   MDD {rep.ls_max_drawdown:.3f}   "
        f"mono {rep.monotonicity:+.2f}   rank-AC {rep.rank_autocorr:+.2f}",
        fontsize=10, family="monospace", color=_INK,
    )

    # (a) 分组平均收益(T+1 柱)+ 长持有期日均当量折线(同分组,ret/h ——
    #     同轴可比:形状不变=排序稳;长端更陡=慢兑现;变平=alpha 衰减)
    ax = fig.add_subplot(gs[0, 0])
    g = rep.group_returns
    vals = g["mean_ret"].to_numpy()
    ax.bar(
        g["group"].to_numpy(), vals,
        color=_sign_colors(vals), edgecolor="white", linewidth=0.5,
        label="T+1",
    )
    gh = rep.group_returns_by_horizon
    if gh.height:
        for hz, style in (("5", dict(ls="-", alpha=0.85)), ("20", dict(ls="--", alpha=0.7))):
            sub = gh.filter(pl.col("horizon") == hz).sort("group")
            if sub.height:
                ax.plot(
                    sub["group"].to_numpy(),
                    sub["mean_ret"].to_numpy() / float(hz),
                    marker=".", ms=3, lw=1.2, color=_INK,
                    label=f"hold {hz}d (/day)", **style,
                )
        if gh.filter(pl.col("horizon").is_in(["5", "20"])).height:
            ax.legend(fontsize=8)
    ax.axhline(0, lw=0.8, color=_INK)
    ax.set_title("a   Mean forward return by factor group (low → high)")
    ax.set_xlabel("group")

    # (b) 日度 IC + 累计 IC
    ax = fig.add_subplot(gs[0, 1])
    ic = rep.ic_by_date["ic"].to_numpy()
    ax.bar(dates, ic, width=1.0, color=_GREY, alpha=0.55)
    ax.axhline(0, lw=0.8, color=_INK)
    ax2 = ax.twinx()
    ax2.spines["right"].set_visible(True)
    ax2.grid(False)
    ax2.plot(dates, np.cumsum(ic), color=_PRIMARY, lw=1.8)
    ax2.tick_params(labelsize=8, colors=_PRIMARY)
    ax2.spines["right"].set_color(_PRIMARY)
    ax.set_title("b   Daily IC (bars, left) & cumulative IC (line, right)")
    _date_axis(ax)

    # (c) 多空与顶/底组累计收益
    ax = fig.add_subplot(gs[1, 0])
    ls = rep.long_short_by_date
    ls_dates = ls["date"].to_list()
    ax.plot(ls_dates, np.cumsum(ls["ls"].to_numpy()), color=_PRIMARY, lw=1.8, label="long−short (directed)")
    ax.plot(ls_dates, np.cumsum(ls["top"].to_numpy()), color=_UP, lw=1.2, label="top group")
    ax.plot(ls_dates, np.cumsum(ls["bottom"].to_numpy()), color=_DOWN, lw=1.2, label="bottom group")
    ax.axhline(0, lw=0.8, color=_INK)
    ax.set_title("c   Cumulative return: top / bottom group & long−short (directed)")
    ax.legend()
    _date_axis(ax)

    # (d) IC 分布
    ax = fig.add_subplot(gs[1, 1])
    ax.hist(
        ic, bins=min(30, max(8, len(ic) // 4)),
        color=_GREY, alpha=0.85, edgecolor="white", linewidth=0.5,
    )
    ax.axvline(0, lw=0.8, color=_INK)
    ax.axvline(rep.ic_mean, lw=1.6, color=_UP, label=f"mean {rep.ic_mean:+.3f}")
    ax.set_title("d   IC distribution")
    ax.legend()
    return fig


def _long_only_page(rep: EvalReport, name: str):
    fig, gs = _new_page(f"Long-Only Top Buckets — {name}")
    fig.text(
        0.06, 0.915,
        "A-share long-only: top-bucket excess vs EQUAL-WEIGHT universe (pure selection);  "
        f"◆ = vs {rep.benchmark_label} (carries beta/size).  net-of-cost t (vs eqw) is primary.",
        fontsize=9, color=_MUTED,
    )
    tb = rep.top_buckets
    labels = tb["bucket"].to_list()
    x = np.arange(len(labels))
    colors = _bucket_palette(len(labels))

    # (a) 各头部桶日均超额：对等权 毛(实心) vs 费后净(描边) + ◆对benchmark(含beta) + t 标注
    ax = fig.add_subplot(gs[0, 0])
    exc = tb["excess_mean"].to_numpy()
    net = tb["net_excess_mean"].to_numpy()
    bex = tb["bench_excess_mean"].to_numpy()
    ax.margins(y=0.2)  # 标注空间
    ax.bar(x - 0.21, exc, width=0.4, color=colors, edgecolor="white",
           linewidth=0.5, label="gross (vs eqw)")
    ax.bar(x + 0.21, net, width=0.4, facecolor="none",
           edgecolor=colors, linewidth=1.3, label="net of cost (vs eqw)")
    ax.scatter(x, bex, marker="D", s=30, color=_INK, zorder=4,
               label="vs benchmark (beta-laden)")
    gts = tb["excess_tstat"].to_list()
    nts = tb["net_excess_tstat"].to_list()
    for xi in range(len(exc)):
        ax.annotate(
            f"{gts[xi]:+.1f}", (xi - 0.21, exc[xi]), textcoords="offset points",
            xytext=(0, 4 if exc[xi] >= 0 else -11), ha="center",
            fontsize=7, color=_MUTED,
        )
        ax.annotate(
            f"{nts[xi]:+.1f}", (xi + 0.21, net[xi]), textcoords="offset points",
            xytext=(0, 4 if net[xi] >= 0 else -11), ha="center",
            fontsize=7, color=_INK, fontweight="bold",
        )
    ax.axhline(0, lw=0.8, color=_INK)
    ax.set_xticks(x, labels)
    ax.legend(fontsize=7)
    ax.set_title("a   Excess vs equal-weight: gross / NET (bars) + ◆ vs-benchmark (beta)")

    # (b) 各头部桶累计超额
    ax = fig.add_subplot(gs[0, 1])
    for label, color in zip(labels, colors):
        sub = rep.top_excess_by_date.filter(
            rep.top_excess_by_date["bucket"] == label
        ).sort("date")
        ax.plot(
            sub["date"].to_list(), np.cumsum(sub["excess"].to_numpy()),
            color=color, lw=1.4, label=label,
        )
    ax.axhline(0, lw=0.8, color=_INK)
    ax.set_title("b   Cumulative excess return by top bucket")
    ax.legend()
    _date_axis(ax)

    # (c) 换手（柱）与胜率（点线）
    ax = fig.add_subplot(gs[1, 0])
    ax.bar(x, tb["turnover"].to_numpy(), color=colors, alpha=0.8,
           edgecolor="white", linewidth=0.5)
    ax.set_ylim(0, 1)
    ax.set_xticks(x, labels)
    ax2 = ax.twinx()
    ax2.spines["right"].set_visible(True)
    ax2.grid(False)
    ax2.plot(x, tb["hit_rate"].to_numpy(), "o-", color=_UP, lw=1.4, markersize=4)
    ax2.set_ylim(0, 1)
    ax2.tick_params(labelsize=8, colors=_UP)
    ax2.spines["right"].set_color(_UP)
    ax.set_title("c   Daily turnover (bars, left) & hit rate (line, right)")

    # (d) 汇总表
    ax = fig.add_subplot(gs[1, 1])
    ax.axis("off")
    lines = [
        f"{'bucket':<7}{'gross':>8}{'g_t':>5}{'net':>8}{'n_t':>5}"
        f"{'hit':>5}{'tov':>5}{'shp':>5}{'mdd':>6}"
    ]
    for r in tb.iter_rows(named=True):
        lines.append(
            f"{r['bucket']:<7}{r['excess_mean']:>+8.4f}{r['excess_tstat']:>+5.1f}"
            f"{r['net_excess_mean']:>+8.4f}{r['net_excess_tstat']:>+5.1f}"
            f"{r['hit_rate']:>5.0%}{r['turnover']:>5.0%}"
            f"{r['sharpe']:>+5.1f}{r['max_drawdown']:>6.3f}"
        )
    lines += [
        "",
        "g_t = gross excess t       n_t = NET excess t (after cost, primary)",
        f"benchmark: {rep.benchmark_label}",
    ]
    ax.text(
        0.0, 0.92, "\n".join(lines), family="monospace", fontsize=8,
        va="top", transform=ax.transAxes, color=_INK,
    )
    ax.set_title("d   Top-bucket summary (n_t = net-of-cost significance)")
    return fig


def _no_data(ax, title: str, hint: str):
    ax.axis("off")
    ax.set_title(title)
    ax.text(0.5, 0.5, hint, ha="center", va="center", fontsize=10, color=_MUTED)


def _decay_decomposition_page(rep: EvalReport, name: str):
    fig, gs = _new_page(f"IC Decay & Decomposition — {name}")

    # (a) IC decay
    ax = fig.add_subplot(gs[0, 0])
    d = rep.decay
    # 口径标注：base = T+1 单日；数字 h = T+1→T+h 持有（逐日滚动、窗口
    # 重叠——非定期调仓模拟，重叠自相关由 NW t 校正）
    labels = [
        "T+1" if h == "base" else f"T+1→T+{h}" for h in d["horizon"].to_list()
    ]
    x = np.arange(len(labels))
    ax.margins(y=0.25)  # 留出标注空间，防止 t 值压到坐标轴
    ax.bar(
        x, d["ic_mean"].to_numpy(),
        color=_bucket_palette(len(labels))[::-1], edgecolor="white", linewidth=0.5,
    )
    for xi, (v, t) in enumerate(zip(d["ic_mean"].to_list(), d["ic_tstat_nw"].to_list())):
        ax.annotate(
            f"t={t:+.1f}", (xi, v), textcoords="offset points",
            xytext=(0, 4 if v >= 0 else -12), ha="center",
            fontsize=8, color=_MUTED,
        )
    ax.axhline(0, lw=0.8, color=_INK)
    # 边际窗口 IC 折线(与累计柱同轴):d1 独高=bounce;后窗走强=慢兑现;平坦=降噪
    mg = rep.ic_marginal
    if mg.height > 1:
        k = min(mg.height, len(labels))
        ax.plot(
            np.arange(k), mg["ic_mean"].to_numpy()[:k],
            marker="o", ms=4, lw=1.4, color=_INK, alpha=0.75,
            label="marginal-window IC",
        )
        for xi, (v, t) in enumerate(zip(mg["ic_mean"].to_list()[:k], mg["ic_tstat_nw"].to_list()[:k])):
            if xi:  # d1 与柱重合不重标
                ax.annotate(f"{mg['window'][xi]}\nt={t:+.1f}", (xi, v),
                            textcoords="offset points", xytext=(0, 8),
                            ha="center", fontsize=7, color=_INK, alpha=0.8)
        ax.legend(fontsize=8, loc="best")
    ax.set_xticks(x, labels)
    ax.set_xlabel("holding horizon (daily rolling, overlapping)")
    ax.set_title("a   IC term structure: cumulative (bars) vs marginal (line)")

    # (b) 月度 IC 热力图
    ax = fig.add_subplot(gs[0, 1])
    ax.grid(False)
    m = rep.ic_by_month
    years = sorted(m["year"].unique().to_list())
    grid = np.full((len(years), 12), np.nan)
    for r in m.iter_rows(named=True):
        grid[years.index(r["year"]), r["month"] - 1] = r["ic_mean"]
    vmax = np.nanmax(np.abs(grid)) or 1.0
    im = ax.imshow(grid, cmap="RdBu_r", vmin=-vmax, vmax=vmax, aspect="auto")
    ax.set_xticks(range(12), [str(i + 1) for i in range(12)])
    ax.set_yticks(range(len(years)), [str(y) for y in years])
    for yi in range(len(years)):
        for mi in range(12):
            v = grid[yi, mi]
            if not np.isnan(v):
                ax.annotate(
                    f"{v:+.2f}", (mi, yi), ha="center", va="center", fontsize=7,
                    color="white" if abs(v) > 0.6 * vmax else _INK,
                )
    cbar = fig.colorbar(im, ax=ax, fraction=0.03)
    cbar.outline.set_visible(False)
    cbar.ax.tick_params(labelsize=7)
    ax.set_title("b   Monthly mean IC")

    # (c) 行业 IC
    ax = fig.add_subplot(gs[1, 0])
    s = rep.ic_by_sector
    if s.height:
        s = s.sort("ic_mean")
        y = np.arange(s.height)
        vals = s["ic_mean"].to_numpy()
        ax.barh(y, vals, color=_sign_colors(vals), edgecolor="white", linewidth=0.5)
        ax.set_yticks(y, s["sector"].to_list(), fontsize=7)
        ax.axvline(0, lw=0.8, color=_INK)
        ax.grid(False)
        ax.xaxis.grid(True, color="#E3E3E3", linewidth=0.6)
        ax.set_title("c   Mean IC by sector (groups ≥5 names/day)")
    else:
        _no_data(ax, "c   Mean IC by sector", "sectors not provided")

    # (d) 市值五分位 IC
    ax = fig.add_subplot(gs[1, 1])
    z = rep.ic_by_size
    if z.height:
        x = np.arange(z.height)
        vals = z["ic_mean"].to_numpy()
        ax.bar(x, vals, color=_sign_colors(vals), edgecolor="white", linewidth=0.5)
        ax.set_xticks(x, z["size_q"].to_list())
        ax.axhline(0, lw=0.8, color=_INK)
        ax.set_title("d   Mean IC by market-cap quintile (Q1 small → Q5 big)")
    else:
        _no_data(ax, "d   Mean IC by market-cap quintile", "mkt_cap not provided")
    return fig


def _calibration_page(rep: EvalReport, name: str):
    """口径对账页：持有期费后存活 + 周内结构（A/B/C 判读，见 AGENTS.md）。"""
    fig, gs = _new_page(f"Trading Calibration — {name}")
    fig.text(
        0.06, 0.915,
        "Reconciliation: portfolio-level claims must decompose into "
        "gross IC + cost structure (case A) or weekday structure (case B); "
        "otherwise phase luck (case C).",
        fontsize=9, color=_MUTED,
    )
    s = rep.holding_survival

    # (a) 各持有期：毛 vs 费后净（日均当量）
    ax = fig.add_subplot(gs[0, 0])
    x = np.arange(s.height)
    ax.margins(y=0.25)
    ax.bar(x - 0.21, s["gross_dly"].to_numpy(), width=0.4,
           color=_bucket_palette(s.height), edgecolor="white", lw=0.5, label="gross /day")
    ax.bar(x + 0.21, s["net_dly"].to_numpy(), width=0.4, facecolor="none",
           edgecolor=_bucket_palette(s.height), lw=1.3, label="net /day")
    for xi, (v, t) in enumerate(zip(s["net_dly"].to_list(), s["net_tstat_nw"].to_list())):
        ax.annotate(f"t={t:+.1f}", (xi + 0.21, v), textcoords="offset points",
                    xytext=(0, 4 if v >= 0 else -11), ha="center", fontsize=8, color=_MUTED)
    ax.axhline(0, lw=0.8, color=_INK)
    ax.set_xticks(x, s["horizon"].to_list())
    ax.legend()
    ax.set_title("a   Top-10% excess by holding horizon: gross vs net (daily-equiv.)")

    # (b) 存活表
    ax = fig.add_subplot(gs[0, 1])
    ax.axis("off")
    lines = [f"{'horizon':<10}{'gross/d':>9}{'tov(h)':>8}{'cost/d':>9}{'net/d':>9}{'t(NW)':>7}"]
    for r in s.iter_rows(named=True):
        lines.append(
            f"{r['horizon']:<10}{r['gross_dly']:>+9.5f}{r['turnover']:>8.0%}"
            f"{r['cost_dly']:>9.5f}{r['net_dly']:>+9.5f}{r['net_tstat_nw']:>+7.1f}"
        )
    lines += ["", "tov(h) = top-10% membership change over h days",
              "cost/d = tov(h) × round-trip cost / h", "",
              "-- fat-tail premise diagnostics --",
              f"tail gradient  top {rep.tail_gradient_top:+.5f}   "
              f"bottom {rep.tail_gradient_bottom:+.5f}",
              f"top-5-day PnL share {rep.top5day_share:.0%}   "
              f"t excl. best 5 days {rep.excess_t_ex_top5:+.1f}",
              "(top5 share high + t collapses -> tail-fragile)"]
    if rep.signal_ac.height:
        _hl = ("inf" if rep.signal_half_life == float("inf")
               else f"{rep.signal_half_life:.1f}d")
        _acs = "  ".join(
            f"L{r['lag']}:{r['ac']:.2f}" for r in rep.signal_ac.iter_rows(named=True)
        )
        lines += ["", "-- signal persistence --",
                  f"rank-AC curve  {_acs}",
                  f"half-life {_hl}   (slow signal: daily rebal wastes cost;",
                  " see (a) net survival for the right horizon)"]
    ax.text(0.0, 0.9, "\n".join(lines), family="monospace", fontsize=9,
            va="top", transform=ax.transAxes, color=_INK)
    ax.set_title("b   Holding-period net survival")

    # (c) 周内 IC 结构
    ax = fig.add_subplot(gs[1, 0])
    w = rep.ic_by_weekday
    wd_names = {1: "Mon", 2: "Tue", 3: "Wed", 4: "Thu", 5: "Fri", 6: "Sat", 7: "Sun"}
    x = np.arange(w.height)
    vals = w["ic_mean"].to_numpy()
    ax.margins(y=0.25)
    ax.bar(x, vals, color=_sign_colors(vals), edgecolor="white", lw=0.5)
    for xi, (v, t) in enumerate(zip(vals, w["t"].to_list())):
        ax.annotate(f"t={t:+.1f}" if t is not None else "", (xi, v),
                    textcoords="offset points", xytext=(0, 4 if v >= 0 else -11),
                    ha="center", fontsize=8, color=_MUTED)
    ax.axhline(0, lw=0.8, color=_INK)
    ax.set_xticks(x, [wd_names.get(v, str(v)) for v in w["wd"].to_list()])
    ax.set_title("c   IC by weekday (case B/C discriminator)")

    # (d) 判读指引
    ax = fig.add_subplot(gs[1, 1])
    ax.axis("off")
    ax.set_title("d   Reading guide")
    guide = (
        "Case A — cost amortization (legit):\n"
        "  gross IC at longer horizon > 0 and net/d\n"
        "  survives as cost is spread over h days.\n\n"
        "Case B — weekday structure (new mechanism):\n"
        "  panel (c) significantly uneven AND a\n"
        "  mechanism story exists -> new card.\n\n"
        "Case C — phase luck (reject):\n"
        "  only one rebalance phase works, no story.\n"
        "  Portfolio-level claims must reconcile with\n"
        "  (a)+(c); the residual is search freedom."
    )
    ax.text(0.0, 0.9, guide, fontsize=9, va="top", transform=ax.transAxes, color=_INK)
    return fig


def _yearly_group_pages(rep: EvalReport, name: str) -> list:
    """逐年 20 组 staircase——过拟合/衰减诊断。

    每年一张子图(2×2,4 图/页,>4 年自动翻页):该年各因子组的均收益柱 + 全样本灰线参考。
    标题给该年 mono(组序号 vs 组均收益的 spearman)与极差 bp。全部子图共享 y 轴,
    使"平年看着也平"——一眼看出阶梯是每年都稳,还是只在训练期成立(CARD 的全样本数字可能虚高)。
    """
    gbd = rep.group_returns_by_date
    if gbd is None or gbd.height == 0:
        return []
    yearly = (
        gbd.with_columns(pl.col("date").dt.year().alias("year"))
        .group_by("year", "group")
        .agg(pl.col("ret").mean().alias("mean_ret"), pl.col("date").n_unique().alias("n_days"))
        .sort("year", "group")
    )
    years = sorted(yearly["year"].unique().to_list())
    if not years:
        return []
    _hi = rep.group_returns.height - 1
    full = rep.group_returns.sort("group")["mean_ret"].to_numpy()  # 全样本参考阶梯
    allv = yearly["mean_ret"].to_numpy()
    ymin, ymax = float(np.nanmin(allv)), float(np.nanmax(allv))
    pad = (ymax - ymin) * 0.12 or 1e-4
    ylim = (ymin - pad, ymax + pad)

    figs = []
    for ps in range(0, len(years), 4):
        chunk = years[ps:ps + 4]
        fig = plt.figure(figsize=(11.7, 8.3))
        page_no = ps // 4 + 1
        n_pages = (len(years) + 3) // 4
        suffix = f" ({page_no}/{n_pages})" if n_pages > 1 else ""
        _draw_title(fig, f"Yearly 20-Group Staircase — {name}{suffix}")
        fig.text(
            0.06, 0.93,
            f"per-year mean forward return by factor group (0 = low … {_hi} = high).  "
            "grey line = full-sample staircase.  does the in-sample monotone hold every year?",
            fontsize=9, color=_MUTED,
        )
        gs = fig.add_gridspec(
            2, 2, top=0.87, bottom=0.07, left=0.06, right=0.97, hspace=0.40, wspace=0.20
        )
        for i, yr in enumerate(chunk):
            ax = fig.add_subplot(gs[i // 2, i % 2])
            sub = yearly.filter(pl.col("year") == yr).sort("group")
            grp = sub["group"].to_numpy()
            vals = sub["mean_ret"].to_numpy()
            mono = sub.select(pl.corr("group", "mean_ret", method="spearman")).item()
            mono = float("nan") if mono is None else float(mono)
            spread = (float(np.nanmax(vals)) - float(np.nanmin(vals))) * 1e4 if len(vals) else float("nan")
            nd = int(sub["n_days"][0]) if sub.height else 0
            ax.bar(grp, vals, color=_sign_colors(vals), edgecolor="white", linewidth=0.5)
            ax.plot(np.arange(len(full)), full, color=_MUTED, lw=1.0, alpha=0.75,
                    marker="o", markersize=2, label="full-sample")
            ax.axhline(0, lw=0.8, color=_INK)
            ax.set_ylim(*ylim)
            ax.set_title(f"{yr}   ({nd}d)   mono={mono:+.2f}   spread={spread:.0f}bp")
            ax.set_xlabel("group")
            if i == 0:
                ax.legend(fontsize=7)
        figs.append(fig)
    return figs


# ======================== 回测报告(backtest_daily -> PDF)========================

def backtest_report_pdf(
    res: dict,
    path: str | Path,
    *,
    name: str = "strategy",
    expo: pl.DataFrame | None = None,
    industry: pl.DataFrame | None = None,
) -> Path:
    """backtest_daily() 结果 → 期刊风格 PDF(与因子报告同视觉规范)。

    页1 总览:NAV(net/gross/bench)/ 回撤 / 累计净超额 / 摘要表。
    页2 动态:日换手 / 持仓数 / 分年 / 分月净超额。
    页3 暴露(传 expo/industry 才出):特征 tilt 条 + 行业占比。
    expo = backtest.exposure() 输出;industry = (sector, share) 两列。
    """
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    bd = res["by_day"].sort("date")
    dates = bd["date"].to_list()
    with plt.rc_context(_RC):
        figs = [_bt_overview_page(res, bd, dates, name), _bt_dynamics_page(res, bd, dates, name)]
        if expo is not None or industry is not None:
            figs.append(_bt_exposure_page(expo, industry, name))
        with PdfPages(path) as pdf:
            for fig in figs:
                pdf.savefig(fig)
                plt.close(fig)
    return path


def _bt_overview_page(res, bd, dates, name):
    fig, gs = _new_page(f"Backtest Overview — {name}")
    fig.text(0.06, 0.90, "daily-decision buffered portfolio · entry/exit at T+1 vwap30 (adj) · "
                         f"cost {res.get('cost_note', '7.5bp/side')} on traded weight",
             fontsize=9, color=_MUTED)
    # a) NAV
    ax = fig.add_subplot(gs[0, 0])
    for col, c, lw, lab in (("net", _PRIMARY, 1.8, "net"), ("gross", _GREY, 1.1, "gross"), ("bench", _MUTED, 1.1, "bench EW")):
        ax.plot(dates, (1 + bd[col]).cum_prod().to_numpy(), color=c, lw=lw,
                ls="-" if col != "bench" else "--", label=lab)
    ax.axhline(1, lw=0.8, color=_INK)
    _date_axis(ax); ax.legend(); ax.set_title("a | NAV (chained daily, vwap30 valuation)")
    # b) drawdown
    ax = fig.add_subplot(gs[0, 1])
    eq = (1 + bd["net"]).cum_prod().to_numpy()
    dd = eq / np.maximum.accumulate(eq) - 1
    ax.fill_between(dates, dd, 0, color=_DOWN, alpha=0.55, lw=0)
    _date_axis(ax); ax.set_title(f"b | net drawdown (max {res['maxdd']:+.1%})")
    # c) cumulative net excess
    ax = fig.add_subplot(gs[1, 0])
    ax.plot(dates, bd["ex_net"].cum_sum().to_numpy(), color=_UP, lw=1.8)
    ax.axhline(0, lw=0.8, color=_INK)
    _date_axis(ax); ax.set_title("c | cumulative net excess vs bench (sum of daily)")
    # d) summary table
    ax = fig.add_subplot(gs[1, 1]); ax.axis("off")
    rows = [
        ("days / avg holdings", f"{res['n_days']}  /  {res['n_hold']:.0f}"),
        ("gross ann / net ann", f"{res['gross_ann']:+.1%}  /  {res['net_ann']:+.1%}"),
        ("net sharpe", f"{res['net_sharpe']:.2f}"),
        ("bench ann (EW)", f"{res['bench_ann']:+.1%}"),
        ("net excess ann / IR", f"{res['ex_net_ann']:+.1%}  /  {res['ex_net_IR']:.2f}"),
        ("turnover (one-way/day)", f"{res['turnover_oneway']:.1%}"),
        ("max drawdown (net)", f"{res['maxdd']:+.1%}"),
    ]
    for i, (k, v) in enumerate(rows):
        ax.text(0.02, 0.92 - i * 0.13, k, fontsize=9.5, color=_MUTED, transform=ax.transAxes)
        ax.text(0.60, 0.92 - i * 0.13, v, fontsize=9.5, color=_INK, fontweight="bold", transform=ax.transAxes)
    ax.set_title("d | summary")
    return fig


def _bt_dynamics_page(res, bd, dates, name):
    fig, gs = _new_page(f"Backtest Dynamics — {name}")
    # a) turnover
    ax = fig.add_subplot(gs[0, 0])
    ax.plot(dates, bd["turn_oneway"].to_numpy(), color=_PRIMARY, lw=0.8)
    ax.axhline(res["turnover_oneway"], color=_UP, lw=1.0, ls="--",
               label=f"mean {res['turnover_oneway']:.1%}")
    _date_axis(ax); ax.legend(); ax.set_title("a | one-way turnover / day")
    # b) holdings count
    ax = fig.add_subplot(gs[0, 1])
    ax.plot(dates, bd["n_hold"].to_numpy(), color=_PRIMARY, lw=1.0)
    _date_axis(ax); ax.set_title("b | holdings count")
    # c) yearly
    ax = fig.add_subplot(gs[1, 0])
    yr = res["yearly"]
    x = np.arange(yr.height)
    ax.bar(x - 0.2, yr["net_ann"].to_numpy(), width=0.4, color=_PRIMARY, label="net ann")
    ax.bar(x + 0.2, yr["ex_net_ann"].to_numpy(), width=0.4, color=_UP, label="net excess ann")
    ax.set_xticks(x); ax.set_xticklabels(yr["y"].to_list())
    ax.axhline(0, lw=0.8, color=_INK); ax.legend(); ax.set_title("c | by year (annualized)")
    # d) monthly net excess
    ax = fig.add_subplot(gs[1, 1])
    mo = (bd.with_columns(m=pl.col("date").dt.strftime("%y-%m"))
            .group_by("m").agg(ex=pl.col("ex_net").sum()).sort("m"))
    vals = mo["ex"].to_numpy()
    ax.bar(np.arange(mo.height), vals, color=[_UP if v >= 0 else _DOWN for v in vals])
    ax.set_xticks(np.arange(mo.height))
    ax.set_xticklabels(mo["m"].to_list(), rotation=60, fontsize=6.5)
    ax.axhline(0, lw=0.8, color=_INK); ax.set_title("d | monthly net excess (sum)")
    return fig


def _bt_exposure_page(expo, industry, name):
    fig, gs = _new_page(f"Backtest Exposure — {name}")
    gs.update(left=0.11, wspace=0.34)  # barh 长标签需要更宽左缘
    fig.text(0.06, 0.90, "feature exposure = daily mean cross-sectional rank of holdings (0.5 = universe-neutral)",
             fontsize=9, color=_MUTED)
    if expo is not None:
        ax = fig.add_subplot(gs[:, 0])
        e = expo.sort("tilt")
        y = np.arange(e.height)
        vals = e["tilt"].to_numpy()
        ax.barh(y, vals, color=[_UP if v >= 0 else _DOWN for v in vals], height=0.62)
        ax.set_yticks(y); ax.set_yticklabels(e["feature"].to_list(), fontsize=8.5)
        ax.axvline(0, lw=0.8, color=_INK)
        ax.set_xlabel("tilt (mean rank − 0.5)")
        ax.set_title("a | factor exposure tilt")
    if industry is not None:
        ax = fig.add_subplot(gs[:, 1])
        d = industry.sort("share").tail(12)
        y = np.arange(d.height)
        ax.barh(y, d["share"].to_numpy(), color=_PRIMARY, height=0.62)
        ax.set_yticks(y); ax.set_yticklabels(d[d.columns[0]].to_list(), fontsize=8.5)
        ax.set_xlabel("share of holdings")
        ax.set_title("b | industry distribution (top)")
    return fig


def quantstats_html(
    res: dict,
    path: str | Path,
    *,
    name: str = "strategy",
    benchmark: pl.DataFrame | None = None,
) -> Path:
    """backtest_daily() 结果 → quantstats HTML 全量分析报告(**同一份里含超额节**)。

    benchmark 可选:不传 = universe 等权(by_day.bench,同票池无技巧对照);
    传 (date, ret) 两列 DataFrame(如 load_index_daily 的指数日收益)则对标该指数。
    quantstats 模板本身只画"策略 vs 基准"两条线,不画差值——本函数在生成的 html 里
    注入一节"Active Excess"(累计净超额曲线 + 年化/IR/回撤,base64 内嵌自包含)。
    收益索引用信号日 T(实际计息 T+1→T+2,策略与基准同口径,相对读数不受影响)。
    """
    import pandas as pd
    import quantstats as qs

    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    bd = res["by_day"].sort("date")
    idx = pd.DatetimeIndex(bd["date"].to_list())
    ret = pd.Series(bd["net"].to_numpy(), index=idx, name=name)
    if benchmark is None:
        bench = pd.Series(bd["bench"].to_numpy(), index=idx, name="universe EW")
    else:
        b = benchmark.sort(benchmark.columns[0])
        rcol = [c for c in b.columns if c != b.columns[0]][0]
        bench = pd.Series(b[rcol].to_numpy(), index=pd.DatetimeIndex(b[b.columns[0]].to_list()), name=rcol)
        bench = bench.reindex(idx).fillna(0.0)  # 对齐到策略交易日
    qs.reports.html(ret, benchmark=bench, output=str(path), title=name, download_filename=path.name)
    _replace_main_chart(path, idx, ret.to_numpy(), bench.to_numpy())
    return path


def _replace_main_chart(path: Path, idx, net, bench) -> None:
    """把 quantstats 主图(第一个内联 SVG = Cumulative Returns vs Benchmark)替换为
    自绘三线图:策略、基准、**超额(相对净值)**同轴同图——超额不再另起一节。"""
    import base64
    import io

    cs = np.cumprod(1 + net) - 1
    cb = np.cumprod(1 + bench) - 1
    cx = (1 + cs) / (1 + cb) - 1                      # 相对净值 − 1(复利口径的超额曲线)
    ex = net - bench
    ir = float(ex.mean()) / (float(ex.std()) + 1e-12) * 244 ** 0.5
    with plt.rc_context(_RC):
        fig, ax = plt.subplots(figsize=(10.8, 5.4), dpi=115)
        ax.plot(idx, cs * 100, color="#348dc1", lw=1.8, label="Strategy")
        ax.plot(idx, cb * 100, color="#d4a017", lw=1.6, label="Benchmark (universe EW)")
        ax.plot(idx, cx * 100, color=_UP, lw=1.8, label=f"Active excess (relative NAV)  IR {ir:.2f}")
        ax.axhline(0, lw=0.9, color=_INK, ls="--", alpha=0.7)
        ax.set_ylabel("%")
        ax.set_title("Cumulative Returns vs Benchmark — with active excess", fontsize=12, loc="left")
        ax.legend(loc="upper left")
        ax.grid(alpha=0.3)
        fig.tight_layout()
        buf = io.BytesIO()
        fig.savefig(buf, format="png")
        plt.close(fig)
    b64 = base64.b64encode(buf.getvalue()).decode()
    tag = f'<img src="data:image/png;base64,{b64}" style="max-width:100%">'
    html = path.read_text()
    i = html.find("<svg")
    j = html.find("</svg>", i)
    if i != -1 and j != -1:
        html = html[:i] + tag + html[j + len("</svg>"):]
    else:  # 找不到主图则退化为附加节
        html = html.replace("</body>", f"<h3>Active Excess</h3>{tag}</body>", 1)
    path.write_text(html)


# ================== 风格暴露照妖镜(attribution -> PDF)==================

def style_mirror_pdf(att: dict, orth: dict, path: str | Path, *, name: str = "model") -> Path:
    """attribution.attribution() + 正交化结果 → 两页 PDF(风格归因 / 信号正交+残差回避侧)。

    att  = attribution() 的返回;
    orth = dict(ic_orig, ic_resid:(date,ic) | bt_orig, bt_resid:backtest_daily 返回
                | groups_resid:(group, mean_ret) 残差20组 | avoid:dict(g0_bp, uni_bp, t))。
    """
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with plt.rc_context(_RC):
        figs = [_mirror_attr_page(att, name), _mirror_orth_page(orth, name)]
        with PdfPages(path) as pdf:
            for fig in figs:
                pdf.savefig(fig)
                plt.close(fig)
    return path


def _mirror_attr_page(att, name):
    fig, gs = _new_page(f"Style Mirror ① Attribution — {name}")
    fig.text(0.06, 0.90,
             f"gross excess ~ style L/S returns ({' / '.join(att['styles'])}) · Newey-West t · "
             f"verdict: R²={att['r2']:.2f}, alpha={att['alpha_ann']:+.1%}/yr (t={att['alpha_t']:+.1f})",
             fontsize=9, color=_MUTED)
    dates = att["dates"]
    # a) 累计:实际超额 vs 风格拟合 vs 残差(alpha 路径)
    ax = fig.add_subplot(gs[0, 0])
    ax.plot(dates, np.cumsum(att["y"]), color=_INK, lw=1.8, label="actual excess")
    ax.plot(dates, np.cumsum(att["fitted"]), color=_PRIMARY, lw=1.4, ls="--", label="style-fitted")
    ax.plot(dates, np.cumsum(att["resid"]) , color=_UP, lw=1.4, label="residual (alpha path)")
    ax.axhline(0, lw=0.8, color=_INK); ax.legend(); _date_axis(ax)
    ax.set_title("a | cumulative: actual vs style-fitted vs residual")
    # b) β 条(带 t)
    ax = fig.add_subplot(gs[0, 1])
    ks = att["styles"]; bs = [att["betas"][k][0] for k in ks]; ts = [att["betas"][k][1] for k in ks]
    yx = np.arange(len(ks))
    ax.barh(yx, bs, color=[_UP if b >= 0 else _DOWN for b in bs], height=0.55)
    for i, (b, t) in enumerate(zip(bs, ts)):
        # 正条:标在条端右侧;负条:标在零线右侧空白(避免挤进 y 轴标签区)
        ax.text(b + 0.01 if b >= 0 else 0.01, i, f"t={t:+.1f}", va="center",
                ha="left", fontsize=8, color=_MUTED)
    ax.set_yticks(yx); ax.set_yticklabels(ks); ax.axvline(0, lw=0.8, color=_INK)
    ax.set_title("b | style betas (NW t)")
    # c) 滚动 60d R²
    ax = fig.add_subplot(gs[1, 0])
    w = 60
    if len(att["y"]) > w:
        rr = []
        for i in range(w, len(att["y"]) + 1):
            ys, fs = att["y"][i - w:i], att["fitted"][i - w:i]
            v = np.var(ys)
            rr.append(1 - np.var(ys - fs) / v if v > 0 else np.nan)
        ax.plot(dates[w - 1:], rr, color=_PRIMARY, lw=1.4)
    ax.axhline(att["r2"], color=_UP, lw=1.0, ls="--", label=f"full R²={att['r2']:.2f}")
    ax.set_ylim(0, 1.05); ax.legend(); _date_axis(ax)
    ax.set_title("c | rolling 60d R² (how style-driven, through time)")
    # d) 摘要
    ax = fig.add_subplot(gs[1, 1]); ax.axis("off")
    rows = [("R² (style-explained)", f"{att['r2']:.2f}"),
            ("alpha ann / NW t", f"{att['alpha_ann']:+.1%}  /  {att['alpha_t']:+.1f}"),
            ("days", f"{att['n']}")]
    rows += [(f"beta {k}", f"{att['betas'][k][0]:+.3f}  (t {att['betas'][k][1]:+.1f})") for k in ks]
    step = min(0.12, 0.88 / len(rows))  # 风格多时自适应行距,防溢出
    fs = 9.5 if step >= 0.09 else 8.0
    for i, (k, v) in enumerate(rows):
        ax.text(0.02, 0.92 - i * step, k, fontsize=fs, color=_MUTED, transform=ax.transAxes)
        ax.text(0.58, 0.92 - i * step, v, fontsize=fs, color=_INK, fontweight="bold", transform=ax.transAxes)
    ax.set_title("d | summary")
    return fig


def _mirror_orth_page(orth, name):
    fig, gs = _new_page(f"Style Mirror ② Orthogonalized Signal — {name}")
    fig.text(0.06, 0.90,
             "score residualized vs styles daily (cross-section) · does ranking survive, and is it monetizable?",
             fontsize=9, color=_MUTED)
    # a) 累计 IC:原始 vs 残差
    ax = fig.add_subplot(gs[0, 0])
    for tag, df, c in (("original", orth["ic_orig"], _GREY), ("residual", orth["ic_resid"], _PRIMARY)):
        s = df.sort("date")
        ax.plot(s["date"].to_list(), s["ic"].cum_sum().to_numpy(), color=c, lw=1.6,
                label=f"{tag}  IC={s['ic'].mean():+.3f}")
    ax.axhline(0, lw=0.8, color=_INK); ax.legend(); _date_axis(ax)
    ax.set_title("a | cumulative daily spearman IC")
    # b) 残差 20 组阶梯(回避侧看底组)
    ax = fig.add_subplot(gs[0, 1])
    g = orth["groups_resid"].sort("group")
    vals = g["mean_ret"].to_numpy() * 1e4
    ax.bar(g["group"].to_numpy(), vals, color=_sign_colors(vals), edgecolor="white", linewidth=0.5)
    ax.axhline(0, lw=0.8, color=_INK)
    ax.set_xlabel("residual-score group (0 = low)"); ax.set_ylabel("mean fwd (bp/day)")
    ax.set_title("b | residual 20-group staircase (bottom = avoid side)")
    # c) 净超额 NAV:原始 vs 残差回测
    ax = fig.add_subplot(gs[1, 0])
    for tag, r, c in (("original scores", orth["bt_orig"], _GREY), ("residual scores", orth["bt_resid"], _PRIMARY)):
        bd = r["by_day"].sort("date")
        ax.plot(bd["date"].to_list(), bd["ex_net"].cum_sum().to_numpy(), color=c, lw=1.6,
                label=f"{tag}  ex {r['ex_net_ann']:+.1%}/yr IR {r['ex_net_IR']:.2f}")
    ax.axhline(0, lw=0.8, color=_INK); ax.legend(); _date_axis(ax)
    ax.set_title("c | buffered backtest: cumulative net excess")
    # d) 摘要(含残差回避侧)
    ax = fig.add_subplot(gs[1, 1]); ax.axis("off")
    io, ir = orth["ic_orig"]["ic"], orth["ic_resid"]["ic"]
    av = orth["avoid"]
    rows = [
        ("IC orig -> resid", f"{io.mean():+.4f}  ->  {ir.mean():+.4f}"),
        ("ICIR ann orig -> resid",
         f"{io.mean()/io.std()*244**0.5:+.1f}  ->  {ir.mean()/ir.std()*244**0.5:+.1f}"),
        ("bt net excess orig", f"{orth['bt_orig']['ex_net_ann']:+.1%}  (IR {orth['bt_orig']['ex_net_IR']:.2f})"),
        ("bt net excess resid", f"{orth['bt_resid']['ex_net_ann']:+.1%}  (IR {orth['bt_resid']['ex_net_IR']:.2f})"),
        ("resid G0 (avoid side)", f"{av['g0_bp']:+.1f} bp/d vs uni {av['uni_bp']:+.1f}  (t {av['t']:+.1f})"),
        ("avoid value (uni - ex G0)", f"{av['overlay_bp']:+.2f} bp/d"),
    ]
    for i, (k, v) in enumerate(rows):
        ax.text(0.02, 0.90 - i * 0.14, k, fontsize=9.5, color=_MUTED, transform=ax.transAxes)
        ax.text(0.52, 0.90 - i * 0.14, v, fontsize=9.5, color=_INK, fontweight="bold", transform=ax.transAxes)
    ax.set_title("d | summary (incl. residual avoid side)")
    return fig
