"""轻量输入契约检查，原从 luxorstockswq 框架内嵌为本包自洽。"""


class ContractError(ValueError):
    """输入表结构与约定不符时抛出。"""


def require_columns(cols, required, context):
    """检查 required 列是否都在 cols 中，缺列则抛 ContractError。"""
    missing = [c for c in required if c not in cols]
    if missing:
        raise ContractError(f"{context}: 缺少必需列 {missing}")
