"""factor_eval: 共享因子评价工具包。

提供：
- evaluate(factor, fwd_ret, ...) -> EvalReport  日度 IC / 分组 / 多空 / 衰减等统计
- report_pdf(rep, path) 等报告导出函数
"""

from factor_eval.evaluate import EvalReport, evaluate
from factor_eval.report import (
    backtest_report_pdf,
    quantstats_html,
    report_pdf,
    style_mirror_pdf,
)

__all__ = [
    "ContractError",
    "EvalReport",
    "evaluate",
    "report_pdf",
    "backtest_report_pdf",
    "quantstats_html",
    "style_mirror_pdf",
]

# 向后兼容：原 luxorstockswq.common._contracts 的 ContractError 也可从 factor_eval 直接导入
from factor_eval._contracts import ContractError
