# factor_eval

共享因子评价工具包。

## 使用

```python
from factor_eval import evaluate, EvalReport, report_pdf

report = evaluate(factor_df, fwd_ret_df)
print(report)
report_pdf(report, "/data/workspace/alice/report.pdf", name="my_factor")
```

## 数据约定

- `factor`: date / code / factor_value
- `fwd_ret`: date / code / fwd_ret（可附加 fwd_ret_5 / fwd_ret_10 等多周期列）
- `benchmark`: date / bench_ret（可选）
- `sectors`: date / code / sector（可选）
- `mkt_cap`: date / code / mkt_cap（可选）
