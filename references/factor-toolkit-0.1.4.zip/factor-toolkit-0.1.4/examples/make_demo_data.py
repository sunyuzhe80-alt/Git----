"""生成一份合成的演示数据，让你在没有真实行情库的情况下跑通整条链路。

产出 demo_data/ 下 5 个 Parquet，列结构与真实环境的表**完全一致**：

    daily.parquet      date/code/open/high/low/close/volume/amount/vwap   （日频表）
    target.parquet     date/code/fwd_ret/fwd_ret_2/_3/_5/_10/_20/buyable  （收益标签）
    benchmark.parquet  date/bench_ret
    sectors.parquet    date/code/sector
    mkt_cap.parquet    date/code/mkt_cap

数据里**埋了一个真实存在的短期反转效应**（过去 5 日涨得多的，未来一日跌回来一点），
所以 quickstart.py 里那个反转因子会跑出显著为正的 IC。这是合成的，不是市场规律，
只是为了让演示报告有东西可看。想看"没用的因子"长什么样，把 REVERSAL 调成 0.0 重跑。

用法：
    python make_demo_data.py                              # 300 只 × 500 个交易日
    python make_demo_data.py --n-codes 500 --n-days 800
"""

from __future__ import annotations

import argparse
import datetime as dt
from pathlib import Path

import numpy as np
import polars as pl

# 埋入的反转强度：次日收益 = -REVERSAL × (过去 5 日累计收益) + 噪声。
# 0.015 配 2% 的日波动，大致给出日度 IC ≈ 0.03——接近一个"确实有效但不夸张"
# 的真实因子量级。调大能看信号变强的样子，调成 0.0 就是纯噪声（因子该失效）。
#
# ⚠ 合成数据没有真实市场的截面相关结构（行业共动、风格暴露、波动聚集都没有），
#   所以这里的 Sharpe / t 值会比真实数据乐观得多。看形状，别看绝对水平。
REVERSAL = 0.015
DAILY_VOL = 0.02
N_SECTORS = 10
HORIZONS = (2, 3, 5, 10, 20)


def trading_days(n: int, start: str = "2021-01-04") -> pl.Series:
    """取 n 个工作日近似交易日历（不扣节假日，演示够用）。"""
    d0 = dt.date.fromisoformat(start)
    cal = pl.date_range(d0, d0 + dt.timedelta(days=int(n * 1.6) + 40), "1d", eager=True)
    days = cal.filter(cal.dt.weekday() <= 5)   # polars: 1=周一 … 7=周日
    if days.len() < n:
        raise RuntimeError("日历不够长，内部参数错了")
    return days.head(n)


def simulate(n_codes: int, n_days: int, seed: int) -> np.ndarray:
    """逐日推进生成收益矩阵，把反转效应真的写进数据生成过程里。返回 (n_days, n_codes)。"""
    rng = np.random.default_rng(seed)
    # 每只票一个固定的波动率乘子，让截面有异质性
    eps = rng.normal(0.0, DAILY_VOL, size=(n_days, n_codes)) * rng.lognormal(0.0, 0.25, n_codes)

    ret = np.zeros((n_days, n_codes))
    ret[:5] = eps[:5]
    for t in range(5, n_days):
        mom5 = ret[t - 5 : t].sum(axis=0)        # 过去 5 日累计收益
        ret[t] = -REVERSAL * mom5 + eps[t]       # ← 反转效应埋在这里
    return ret


def build_frames(n_codes: int, n_days: int, seed: int) -> dict[str, pl.DataFrame]:
    rng = np.random.default_rng(seed + 1)
    ret = simulate(n_codes, n_days, seed)

    price0 = 10.0 * rng.uniform(0.5, 3.0, size=n_codes)
    close = price0 * np.cumprod(1.0 + ret, axis=0)

    dates = trading_days(n_days)
    codes = [f"{i:06d}" for i in range(1, n_codes + 1)]

    # 长表骨架。ret/close 是 (n_days, n_codes) 的 C order，ravel 后
    # date 是外层（repeat）、code 是内层（tile），两者必须这样配对。
    n = n_days * n_codes
    base = (
        pl.DataFrame({"date": dates})
        .join(pl.DataFrame({"code": codes}), how="cross")   # date 外层、code 内层
        .with_columns(close=pl.Series(close.ravel()), ret=pl.Series(ret.ravel()))
    )

    # ---- 日频表：由 close/ret 反推出一组自洽的 OHLC
    c = base["close"].to_numpy()
    r = base["ret"].to_numpy()
    prev_c = c / (1.0 + r)
    swing = np.abs(rng.normal(0.0, 0.01, size=n))
    open_ = prev_c * (1.0 + rng.normal(0.0, 0.006, size=n))
    high = np.maximum(open_, c) * (1.0 + swing)
    low = np.minimum(open_, c) * (1.0 - swing)
    vwap = (open_ + high + low + c) / 4.0
    volume = rng.lognormal(13.0, 0.8, size=n).round()

    daily = base.select("date", "code").with_columns(
        open=pl.Series(open_),
        high=pl.Series(high),
        low=pl.Series(low),
        close=base["close"],
        volume=pl.Series(volume),
        amount=pl.Series(volume * vwap),
        vwap=pl.Series(vwap),
    ).sort("code", "date")

    # ---- 收益标签：T 日出信号、T+1 入场，持有 h 日 = close[T+h]/close[T] - 1
    #      （与真实 target 的日期约定一致：date 是因子信息截止日）
    target = (
        base.select("date", "code", "close")
        .sort("code", "date")
        .with_columns(
            (pl.col("close").shift(-1) / pl.col("close") - 1.0).over("code").alias("fwd_ret"),
            *[
                (pl.col("close").shift(-h) / pl.col("close") - 1.0).over("code").alias(f"fwd_ret_{h}")
                for h in HORIZONS
            ],
        )
        # buyable：约 2% 的行当日不可买（涨停/停牌的替身）
        .with_columns(buyable=pl.Series(rng.random(n) > 0.02))
        .drop("close")
    )

    benchmark = (
        base.group_by("date").agg(pl.col("ret").mean().alias("bench_ret")).sort("date")
    )

    sectors = base.select(
        "date",
        "code",
        sector=pl.Series(np.tile(
            np.array([f"S{s:02d}" for s in rng.integers(0, N_SECTORS, n_codes)]), n_days
        )),
    )

    # 市值 = 固定的流通股本 × 当日价格
    shares = rng.lognormal(19.0, 1.0, size=n_codes)
    mkt_cap = base.select("date", "code", mkt_cap=pl.Series(np.tile(shares, n_days) * c))

    return {
        "daily": daily,
        "target": target,
        "benchmark": benchmark,
        "sectors": sectors,
        "mkt_cap": mkt_cap,
    }


def main() -> None:
    p = argparse.ArgumentParser(
        description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter
    )
    p.add_argument("--n-codes", type=int, default=300, help="股票数（evaluate 固定 20 组，建议 >= 100）")
    p.add_argument("--n-days", type=int, default=500, help="交易日数")
    p.add_argument("--seed", type=int, default=20260915)
    p.add_argument("--out", type=Path, default=Path(__file__).parent / "demo_data")
    args = p.parse_args()

    if args.n_codes < 100:
        p.error(f"--n-codes={args.n_codes} 太少：evaluate 固定分 20 组，每组至少要有几只票才有意义")

    frames = build_frames(args.n_codes, args.n_days, args.seed)
    args.out.mkdir(parents=True, exist_ok=True)
    for name, df in frames.items():
        path = args.out / f"{name}.parquet"
        df.write_parquet(path)
        print(f"  {path}  {df.height:,} 行 × {df.width} 列")
    print(f"\n完成：{args.n_codes} 只 × {args.n_days} 个交易日 → {args.out}")
    print("接着跑：python quickstart.py")


if __name__ == "__main__":
    main()
