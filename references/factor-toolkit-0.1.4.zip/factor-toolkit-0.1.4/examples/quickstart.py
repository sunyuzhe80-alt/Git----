"""端到端演示：行情 → 因子 → evaluate → PDF 报告。

跑之前先生成数据：
    python make_demo_data.py
然后：
    python quickstart.py

你自己接真实数据时，只需要替换第 1 步（读数）和第 2 步（算因子）。
第 3 步之后一个字都不用改。
"""

from __future__ import annotations

from pathlib import Path

import polars as pl

import factor_ops as ops
from factor_eval import evaluate, report_pdf

DATA = Path(__file__).parent / "demo_data"
OUT = Path(__file__).parent / "out"


def main() -> None:
    if not (DATA / "target.parquet").exists():
        raise SystemExit(f"找不到 {DATA}，先跑：python make_demo_data.py")
    OUT.mkdir(exist_ok=True)

    # ---------------------------------------------------------------- 1. 读数
    # 接自己的数据时，这两行换成你的日线表和收益标签表（列要求见 docs/api_manual.md 第 1 节）
    daily = pl.read_parquet(DATA / "daily.parquet").sort("code", "date")
    tgt = pl.read_parquet(DATA / "target.parquet")

    # buyable 必须先过滤：当日涨停/停牌的票买不进去，留着会把评价做虚
    tgt = tgt.filter(pl.col("buyable")).sort("code", "date")

    # ------------------------------------------------- 2. 算因子（你要替换的部分）
    # 演示因子：5 日反转 —— 过去 5 日涨幅的截面秩，取负号。
    #
    # ⚠ 关键规则：ts_* 内建 .over("code")、cs_* 内建 .over("date")，
    #   直接套写（cs_rank(ts_delta(...))）不报错，但整列静默变成 null。
    #   必须像下面这样分两个 with_columns 落列。
    factor = (
        daily.with_columns(
            ops.ts_delta(ops.s_log("close"), 5).alias("_mom5")   # 第一步：时序
        )
        .with_columns(
            (-ops.cs_rank("_mom5")).alias("factor_value")         # 第二步：截面
        )
        .select("date", "code", "factor_value")
        .drop_nulls()
    )
    # 契约：date / code / factor_value 三列，(date, code) 唯一
    assert factor.select(pl.struct("date", "code").n_unique()).item() == factor.height

    # ------------------------------------------------------- 3. 评价（主口径 T+1）
    labels = tgt.select(
        "date", "code", "fwd_ret", "fwd_ret_5", "fwd_ret_10", "fwd_ret_20"
    ).drop_nulls("fwd_ret")

    benchmark = pl.read_parquet(DATA / "benchmark.parquet")
    sectors = pl.read_parquet(DATA / "sectors.parquet")
    mkt_cap = pl.read_parquet(DATA / "mkt_cap.parquet")

    rep = evaluate(
        factor,
        labels,
        n_groups=20,
        benchmark=benchmark,   # 可选：不传则退化为票池等权
        sectors=sectors,       # 可选：产出分行业 IC
        mkt_cap=mkt_cap,       # 可选：产出市值五分位 IC
    )
    print(rep)
    print()

    # ------------------------------------------------------------- 4. PDF 报告
    pdf = report_pdf(rep, OUT / "reversal_5d.pdf", name="reversal_5d")
    print(f"报告已写出：{pdf}")

    # --------------------------------------- 5. 换持有期：T+5（别忘了 overlap_h）
    labels5 = (
        tgt.select("date", "code", "fwd_ret_5")
        .rename({"fwd_ret_5": "fwd_ret"})
        .drop_nulls()
    )
    rep5 = evaluate(factor, labels5, n_groups=20, overlap_h=5)
    #                                             ^^^^^^^^^^^ 重叠标签，不填 t 值会虚高约 √5
    print("--- T+5 口径 ---")
    print(f"IC mean={rep5.ic_mean:+.4f}  t={rep5.ic_tstat:+.2f}  mono={rep5.monotonicity:+.2f}")

    # ------------------------------------------- 6. 想自己取数的话，结果都是 DataFrame
    print("\n分组阶梯（G0 = 因子值最低组）：")
    print(rep.group_returns)


if __name__ == "__main__":
    main()
