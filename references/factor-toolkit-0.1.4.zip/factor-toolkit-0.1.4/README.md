# factor-toolkit 0.1.4

因子评价工具包。定位和 [alphalens](https://github.com/quantopian/alphalens) 一样：
**你给一张因子表和一张远期收益表，它告诉你这个因子有没有用**，并出一份 PDF 报告。

两个包，都是源码：

| 包 | 干什么 |
|---|---|
| `factor_ops` | 算子库。截面 / 时序 / 日度聚合 / 微结构原语，因子 = 算子的组合 |
| `factor_eval` | 评价器。IC、分组阶梯、多空、头部分层、衰减、尾部诊断 + PDF 报告 |

底层是 [Polars](https://pola.rs)，不是 pandas。因子表和收益表都是 `polars.DataFrame`。

---

## 1. 安装

要求 **Python ≥ 3.10**（源码里用了 `str | pl.Expr` 这种注解写法，3.9 一 import 就报错）。

```bash
cd factor-toolkit-0.1.4
pip install ./factor_ops ./factor_eval
```

依赖只有三个：`polars>=1.21`、`numpy>=1.24`、`matplotlib>=3.7`，pip 会自动装。

> **polars 必须 ≥ 1.21。** 滚动窗口的 `min_periods` 参数在 1.21 被改名成 `min_samples`，
> 旧名直接删了——低于这个版本，所有 `ts_*` 滚动算子全部报错。

想改代码就用可编辑安装：

```bash
pip install -e ./factor_ops -e ./factor_eval
```

**可选**：`quantstats_html()` 这一个函数需要 quantstats（它在函数体内才 import，
不装不影响其余任何功能，**PDF 报告是纯 matplotlib 出的，用不到它**）。
真要出 HTML 报告再装：

```bash
pip install "./factor_eval[html]"
```

这一步会拖下 pandas / scipy / yfinance / lxml 一大串（解压后约 500MB），所以默认不装。

验证：

```bash
python -c "import factor_ops, factor_eval; print('ok')"
```

## 2. 五分钟跑通

包里带了合成数据生成器，**不需要任何真实行情库**就能把整条链路跑一遍：

```bash
cd examples
python make_demo_data.py     # 生成 300 只 × 500 个交易日的合成面板
python quickstart.py         # 因子 → evaluate → PDF
```

跑完你会看到一行摘要，和 `examples/out/reversal_5d.pdf`。

演示数据里**故意埋了一个短期反转效应**（过去 5 日涨多的，次日跌回来一点），
所以那个反转因子的 IC 会显著为正。这是合成的，不是市场规律，只是让报告有东西可看。
想看"没用的因子"长什么样，把 `make_demo_data.py` 里的 `REVERSAL` 调成 `0.0` 重跑。

## 3. 接你自己的数据

你只需要造两张表。**对齐和无前视是你的责任，评价器只做统计，它不检查你有没有偷看未来。**

**因子表**

| 列 | 说明 |
|---|---|
| `date` / `code` | 键，`(date, code)` 必须唯一 |
| `factor_value` | Float64。方向随意，评价器自动定方向 |

**远期收益表**

| 列 | 说明 |
|---|---|
| `date` / `code` | 键，唯一 |
| `fwd_ret` | Float64，主口径远期收益（T 日出信号 → T+1 的收益） |
| `fwd_ret_2` / `_5` / `_10` … | 可选，多持有期。列名必须是 `fwd_ret_<整数>`，自动产出 IC decay |

从日线造收益标签：

```python
labels = daily.sort("code", "date").with_columns(
    (pl.col("close").shift(-1) / pl.col("close") - 1).over("code").alias("fwd_ret"),
    (pl.col("close").shift(-5) / pl.col("close") - 1).over("code").alias("fwd_ret_5"),
)
```

然后：

```python
from factor_eval import evaluate, report_pdf

rep = evaluate(factor, labels, n_groups=20)
print(rep)
report_pdf(rep, "my_factor.pdf", name="my_factor")
```

可选参数 `benchmark`（date/bench_ret）、`sectors`（date/code/sector）、
`mkt_cap`（date/code/mkt_cap）分别给出对标超额、分行业 IC、分市值 IC。

**换持有期记得加 `overlap_h`**：

```python
labels5 = labels.select("date","code","fwd_ret_5").rename({"fwd_ret_5":"fwd_ret"}).drop_nulls()
rep5 = evaluate(factor, labels5, n_groups=20, overlap_h=5)   # ← 不填 t 值会虚高约 √5
```

## 4. 写因子时唯一容易踩的坑

`cs_*` 内建了 `.over("date")`，`ts_*` 内建了 `.over("code")`。**两者直接嵌套不会报错，
但结果整列是 null**：

```python
# ✗ 不报错，但 factor_value 全是 null
df.with_columns(ops.cs_rank(ops.ts_delta("close", 5)).alias("factor_value"))

# ✓ 分两步落列
df.with_columns(ops.ts_delta("close", 5).alias("_mom")) \
  .with_columns(ops.cs_rank("_mom").alias("factor_value"))
```

因子整列变 null 的时候，先来查这一条。

## 5. 报告怎么读

`print(rep)` 的输出，从上往下：

- **`IC mean` / `t`** —— 日度 Spearman IC 的均值和 t 值。`|t| > 2` 才算显著。第一眼看这个。
- **`mono`** —— 20 组的组号和组均收益的秩相关。接近 ±1 说明分组单调，因子有稳定的排序能力；
  接近 0 说明只有尾部有效。
- **`Groups G0..G19`** —— 分组阶梯本身，按因子值**升序**分组。
- **`Long top 5% / top 10%`** —— 头部分层。`net` 是扣掉换手成本后的超额，
  这个为正才有实盘意义；`tov` 是换手。
- **`Tails top5day_share`** —— 头部累计超额里最好的 5 天占了多少。这个数很大（比如 >50%）
  说明收益全靠几天暴击，很脆。`t_ex_top5` 是剔掉最好 5 天后的 t 值，崩了就是尾部脆弱。
- **`Decay`** —— 各持有期的 IC，看 alpha 衰减多快。

`rep` 是个 dataclass，`rep.group_returns` / `rep.top_buckets` / `rep.decay` 等等
都是 polars DataFrame，可以直接取出来自己画。全部字段见 `docs/api_manual.md` 第 3.2 节，
或者直接读 `factor_eval/src/factor_eval/evaluate.py` 里 `EvalReport` 的定义——每个字段都有注释。

## 6. 常见提示和报错

**`[report] 未找到 CJK 字体，中文将渲染为方块`**

只影响报告里的中文字符。中文只可能出现在"分行业 IC"那张图的行业名上——
如果你传给 `evaluate` 的 `sectors` 里行业名是中文，就需要一个中文字体；
行业名是英文/代码（或者压根没传 `sectors`）的话，这条提示可以直接忽略。

要中文的话，装任意一个 CJK 字体即可（它会自动扫 `~/.fonts` 和 `/usr/share/fonts`
里名字含 `cjk` / `noto` / `wqy` / `hei` 的字体），或者直接指路径：

```bash
export LUX_CJK_FONT=/path/to/NotoSansSC-Regular.ttf
```

**`findfont: Failed to find font weight semibold for DejaVu Sans, now using 700`**

matplotlib 的噪音，无害，报告一切正常。

**`ts_*` 算子报 `min_periods` 相关的错** —— polars 版本低于 1.21，升级即可（见第 1 节）。

**`import factor_ops` 报 `TypeError: unsupported operand type(s) for |`** —— Python 是 3.9
或更低，升到 3.10+。

**因子算出来整列是 null** —— 见第 4 节的嵌套规则，九成是这个。

## 7. 这个包里**没有**什么

说清楚免得白找：

- **没有回测引擎。** `factor_eval` 是因子评价器，不是回测系统——和 alphalens 一样。
  `report.py` 里的 `backtest_report_pdf(res, ...)` / `quantstats_html(res, ...)` 只是**画图函数**，
  它们要的 `res` 字典（`by_day` / `turnover` / `maxdd` / `yearly` …）得你自己的
  组合引擎产出。字段清单见 `docs/api_manual.md` 第 3.4 节。
- **没有行情数据，也没有取数工具。** 行情、收益标签都得你自己准备——手册第 1 节说明了
  这些函数对你的表有什么要求。想先跑通流程的话，`examples/make_demo_data.py`
  会造一份合成数据顶上。

## 8. 包内文件

```
factor-toolkit-0.1.4/
├── README.md                    ← 你正在看的
├── factor_ops/                  ← 算子库（源码）
│   ├── pyproject.toml
│   ├── README.md
│   └── src/factor_ops/*.py
├── factor_eval/                 ← 评价器（源码）
│   ├── pyproject.toml
│   ├── README.md
│   └── src/factor_eval/*.py
├── docs/
│   ├── api_manual.md            ← 完整 API 手册：算子清单 + 每个报告字段的含义
│   └── factor_api_manual.pdf    ← 同上，PDF 版
└── examples/
    ├── make_demo_data.py        ← 合成数据生成器
    └── quickstart.py            ← 端到端示例
```

手册（`docs/api_manual.md`，同目录下有 PDF 版）是这两个包的完整接口文档：

- **第 1 节 接口契约** —— 每族函数要求你的 DataFrame 有哪些列、怎么排序。
  注意这讲的是**函数的前置条件**，不是对数据源的规范：行情从哪来、收益标签怎么算，
  都由你决定，这些函数不检查也不关心。
- **第 2 节 算子清单** —— 64 个算子，按 `cs_*` / `ts_*` / `d_*` / `add_*` 分族列全。
- **第 3 节 评价器** —— `evaluate` 的参数、`EvalReport` 的每一个字段。
- **第 4 节 排错** —— 按出现频率排的常见问题。
